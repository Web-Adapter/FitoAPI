<?php

namespace FitoApi\utils;

use FitoApi\manager\EconomyManager;
use FitoApi\Main;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;

abstract class Helper {

    const ADMINS = ['velunis', '_cokojl_'];
    const COMMANDS = ["rca", "slapper", "giveamethysts", "givemoney", "kill", "setworldspawn", "restart", "wl", "log", "give", "effect", "miec", "mapimageengine", "mie", "/set", "deop", "whitelist", "timings", "save-all", "save-off", "save-on", "seed", "setspawn", "status", "fperms", "cpardon", "biome"];

    public static function convertTimeOptimized(int $seconds) {
        $days = floor($seconds / (24 * 3600));
        $hours = floor(($seconds % (24 * 3600)) / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $remainingSeconds = $seconds % 60;

        $result = '';

        if ($days > 0) {
            $result .= '§6' . $days . ' §eд. ';
        }

        if ($hours > 0) {
            $result .= '§6' . $hours . ' §eч. ';
        }

        if ($minutes > 0) {
            $result .= '§6' . $minutes . ' §eм. ';
        }

        if ($remainingSeconds > 0) {
            $result .= '§6' . $remainingSeconds . ' §eс.';
        }

        return trim($result);
    }

    public static function getWorldName($world) {
        $worldNames = [
            'pvparena' => '§aPvP-Арена§r ',
            'world' => '§a§lВыживание§r ',
            'spawn' => '§eСпавн§r ',
            'clanwar' => '§4Война§r ',
            'eventWorld' => '§dЛогово Короля§r '
            ];

        if (strpos($world, 'void') !== false) {
            $worldNames[$world] = '§a§lПаркур§r ';
        } elseif (!isset($worldNames[$world])) {
            $worldNames[$world] = null;
        }

        return $worldNames[$world];
    }
}