<?php

namespace FitoApi\command\money;

use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use FitoApi\Main;
use FitoApi\manager\EconomyManager;
use FitoApi\utils\Helper;

class PayCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct('pay', 'Перевод игровой валюты');
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $player, $label, array $args) {
        $playerName = strtolower($player->getName());

        if ($this->plugin->getTime($player) < 3600) {
            $player->sendMessage("§7► §cДля возможности совершать переводы другим игрокам нужно наиграть на сервере §61 §eчас");
            return;
        }

        if(!isset($args[0]) or !isset($args[1]) or !is_numeric($args[1]) or $args[1] <= 0 or strpos($args[1], ".") !== false) {
            $player->sendMessage("§7► §eИспользование§7: §7/§6pay (никнейм) (сумма)");
            return;
        } 

        if(!($recipient = $this->plugin->getServer()->getPlayer($args[0])) instanceof Player) {
            $player->sendMessage("§8[§6Экономика§8] §cИгрок сейчас не в игре!");
            return;
        }

        if($playerName == $recipient->getName()) {
            $player->sendMessage("§8[§6Экономика§8] §cТы не можешь перевести деньги самому себе!");
            return;
        }

        if(EconomyManager::myMoney($player) < $args[1]) {
            $player->sendMessage("§8[§6Экономика§8] §cНедостаточно денег для совершения перевода на введенную тобой сумму!");
            return;
        }

        EconomyManager::addMoney($recipient, $args[1]);
        EconomyManager::reduceMoney($player, $args[1]);

        $player->sendMessage("§8[§6Экономика§8] §eТы успешно перевел игроку §a" . $recipient->getName() . " §l§e" . $args[1] . '§6$§r');
        $recipient->sendMessage("§8[§6Экономика§8] §eИгрок §a" . $playerName  . " §eперевел тебе §l§e" . $args[1] . '§6$§r');
    }
}