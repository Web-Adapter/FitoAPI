<?php

namespace FitoApi\command\money;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use FitoApi\Main;
use FitoApi\manager\EconomyManager;

class MoneyCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct('money', 'Просмотр баланса игровой валюты', null, ['mymoney']);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $player, $label, array $args) {
        $playerName = strtolower($player->getName());

        $player->sendMessage("§8[§6Экономика§8] §eТвой баланс игровой валюты§7: §l§e" . EconomyManager::myMoney($player) . '§6$§r');
    }
}