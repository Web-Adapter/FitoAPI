<?php

namespace FitoApi\command\money;

use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use FitoApi\Main;
use FitoApi\manager\EconomyManager;

class SeeMoneyCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct('seemoney', 'Просмотр баланса игровой валюты другого игрока');
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        $senderName = strtolower($sender->getName());

        if(!isset($args[0])) {
            $sender->sendMessage("§7► §eИспользование§7: §7/§6seemoney (никнейм)");
            return;
        }

        if(!($senderVisible = $this->plugin->getServer()->getPlayer($args[0])) instanceof Player) {
            $sender->sendMessage("§8[§6Экономика§8] §cИгрок сейчас не в игре!");
            return;
        }

        if($senderName == $senderVisible->getName()) {
            $sender->sendMessage("§8[§6Экономика§8] §eВоспользуйся командой §7/§6mymoney §eдля просмотра своего баланса игровой валюты!");
            return;
        } 

        $sender->sendMessage("§8[§6Экономика§8] §eБаланс игровой валюты игрока §a" . $senderVisible->getName() . "§7: §l§e" . EconomyManager::myMoney($senderVisible) . '§6$§r');
    }
}