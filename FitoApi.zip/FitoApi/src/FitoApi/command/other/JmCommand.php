<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use FitoApi\Main;

class JmCommand extends Command {
    
	public function __construct() {
		parent::__construct("jm");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("jm.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset(Main::getInstance()->sozd[$sender->getLowerCaseName()])){
		Main::getInstance()->sozd[$sender->getLowerCaseName()] = true;
        $sender->sendMessage("§7► §eТы §aвключил §eоповещения о твоем входе");
		}else{
		unset(Main::getInstance()->sozd[$sender->getLowerCaseName()]);
		$sender->sendMessage("§7► §eТы §cотключил §eоповещения о твоем входе");
		}
	}
}