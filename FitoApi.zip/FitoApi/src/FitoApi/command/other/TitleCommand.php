<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\{Player, Server};

class TitleCommand extends Command {
    
	public function __construct() {
		parent::__construct("title");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("title.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        if(count($args) == 0) return $sender->sendMessage("§7► §eИспользование§7: §7/§6title §fсообщение");
        
        $title = implode(" ", $args);
        
        if(strlen($title) > 30) return $sender->sendMessage("§7► §cМаксимальное количество символов §7- §a30");
               
        Server::getInstance()->broadcastTitle("§а".$sender->getName(), "§7".$title);
	}
}