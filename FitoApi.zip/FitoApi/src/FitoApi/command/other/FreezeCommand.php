<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use FitoApi\Main;

use pocketmine\Server;

class FreezeCommand extends Command {
    
	public function __construct() {
		parent::__construct("freeze");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("freeze.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset($args[0])) return $sender->sendMessage('§7► §eИспользование§7: §7/§6freeze (никнейм)');
		if(isset(Main::getInstance()->freezeUse[$sender->getLowerCaseName()])) return $sender->sendMessage('§7► §cЭту команду можно использовать один раз на перезагрузку');
		$online = Server::getInstance()->getPlayer($args[0]);
		if(!$online) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
		if(strtolower($online->getName()) === strtolower($sender->getName())) return $sender->sendMessage('§7► §cТы не можешь заморозить самого себя');
		Main::getInstance()->freezeUse[$sender->getLowerCaseName()] = true;
		Main::getInstance()->freeze[$online->getLowerCaseName()] = true;
		$sender->sendMessage('§7► §eТы успешно §bзаморозил §eигрока§a '.$online->getName());
		$online->sendMessage('§7► §eИгрок§a '.$sender->getName().' §eуспешно §bзаморозил §eтебя! Перезайди в игру!');
	}
}