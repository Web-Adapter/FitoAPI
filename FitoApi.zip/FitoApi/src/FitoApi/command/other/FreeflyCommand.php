<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\{Player, Server};

use FitoApi\Main;

class FreeflyCommand extends Command {
    
	public function __construct() {
		parent::__construct("freefly");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("freefly.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        if(!isset($args[0]) or isset($args[1])) return $sender->sendMessage("§7► §eИспользование§7: §7/§6freefly (никнейм)");
        
        if(isset(Main::getInstance()->freefly[$sender->getLowerCaseName()])) return $sender->sendMessage("§7► §cДанная команда будет доступа после рестарта");
        
        $targetPlayer = Server::getInstance()->getPlayer($args[0]);
        
        if($targetPlayer == null) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
        
        $targetPlayer->setAllowFlight(true);
        
        Main::getInstance()->freefly[$sender->getLowerCaseName()] = true;
        
        $targetPlayer->sendMessage("§7► §eИгрок §a".$sender->getName()." §eвыдал тебе §6флай §eдо перезагрузки");
        
        $sender->sendMessage("§7► §eТы выдал игроку §a".$targetPlayer->getName()." §6флай §eдо перезагрузки");
	}
}