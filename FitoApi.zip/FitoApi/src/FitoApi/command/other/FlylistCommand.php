<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\{Player, Server};

class FlylistCommand extends Command {
    
	public function __construct() {
		parent::__construct("flylist");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("flylist.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        $list = "";
        
        foreach(Server::getInstance()->getOnlinePlayers() as $player) {
			if($player->getAllowFlight(true) and $player->getGamemode() == 0) {
				$list .= $player->getName().", ";
			}
		}
		
		$sender->sendMessage("§7► §eСписок игроков во §6флае§7:\n§7— §f".substr($list, 0, -2));
	}
}