<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use FitoApi\Main;

use pocketmine\Server;

class UnFreezeCommand extends Command {
    
	public function __construct() {
		parent::__construct("unfreeze");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("freeze.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset($args[0])) return $sender->sendMessage('§7► §eИспользование§7: §7/§6unfreeze (никнейм)');
		$online = Server::getInstance()->getPlayer($args[0]);
		if(!$online) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
		if(strtolower($online->getName()) === strtolower($sender->getName())) return $sender->sendMessage('§7► §cТы не можешь разморозить самого себя');
		if(!isset(Main::getInstance()->freeze[$online->getLowerCaseName()])) return $sender->sendMessage('§7► §cИгрок не заморожен');
		unset(Main::getInstance()->freeze[$online->getLowerCaseName()]);
		$sender->sendMessage('§7► §eТы успешно разморозил игрока §a'.$online->getName());
		$online->sendMessage('§7► §eИгрок §a'.$sender->getName().' §eуспешно разморозил тебя');
	}
}