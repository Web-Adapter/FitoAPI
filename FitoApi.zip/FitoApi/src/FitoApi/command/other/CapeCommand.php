<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

class CapeCommand extends Command {
    
	public function __construct() {
		parent::__construct("cape");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("cape.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		$sender->setSkin($sender->getSkinData(), 'Minecon_MineconSteveCape2011');
        $sender->sendMessage("§7► §aВы установили плащ на свой скин!");
	}
}