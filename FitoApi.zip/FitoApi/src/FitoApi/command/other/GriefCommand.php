<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use pocketmine\Server;

use FitoApi\Main;

class GriefCommand extends Command {
    
	public function __construct() {
		parent::__construct("grief");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
		if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
		if(isset(Main::getInstance()->grief[$sender->getLowerCaseName()])) return $sender->sendMessage("§7► §cДанная команда будет доступа после рестарта");
		if(!$sender->hasPermission("grief.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset($args[0])) return $sender->sendMessage('§f▶ §eИспользование§7: §7/§6grief (никнейм)');
		$online = Server::getInstance()->getPlayer($args[0]);
		if(!$online) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
		if(strtolower($online->getName()) === strtolower($sender->getName())) return $sender->sendMessage('§7► §cТы не можешь забрать предмет у самого себя');
		if(!$online->isSurvival()) return $sender->sendMessage('§7► §cИгрок должен находится в режиме Выживания');
		Main::getInstance()->grief[$sender->getLowerCaseName()] = true;
		$item = $online->getInventory()->getItemInHand();
		$online->getInventory()->removeItem($item);
		$sender->getInventory()->addItem($item);
		$online->sendMessage('§7► §eИз твоей руки забрал предмет игрок §a'.$sender->getName());
		$sender->sendMessage('§7► §eТы успешно забрал предмет из руки игрока §a'.$online->getName());
	}
}