<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use FitoApi\Main;

use pocketmine\Server;

class CopyCommand extends Command {
    
	public function __construct() {
		parent::__construct("copy");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
		if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
		if(isset(Main::getInstance()->copy[$sender->getLowerCaseName()])) return $sender->sendMessage("§7► §cДанная команда будет доступа после рестарта");
		if(!$sender->hasPermission("copy.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset($args[0])) return $sender->sendMessage('§7► §eИспользование§7: §7/§6copy (никнейм)');
		$online = Server::getInstance()->getPlayer($args[0]);
		if(!$online) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
		if(strtolower($online->getName()) === strtolower($sender->getName())) return $sender->sendMessage("§7► §cТы не можешь скопировать свой инвентарь");
		if(!$online->isSurvival()) return $sender->sendMessage('§7► §cИгрок должен находится в режиме Выживания');
		Main::getInstance()->copy[$sender->getLowerCaseName()] = true;
		$items = $online->getInventory()->getContents();
		foreach($items as $slots => $lol){
			$sender->getInventory()->setItem($slots, $lol);
		}
		$online->sendMessage('§7► §eТвой инвентарь был скопирован игроком §a'.$sender->getName());
		$sender->sendMessage('§7► Ты успешно скопировал инвентарь игрока §a'.$online->getName());
	}
}