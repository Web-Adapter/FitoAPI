<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\{Player, Server};

use FitoApi\Main;

class DonatelistCommand extends Command {
    
	public function __construct() {
		parent::__construct("donatelist");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("donatelist.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        $list = "";
        
        foreach(Server::getInstance()->getOnlinePlayers() as $player) {
            $group = Main::getInstance()->groups->getUserDataMgr()->getGroup($player)->getName();
            
			if($group != "Игрок") {
				$list .= "§a".$group." §f".$player->getName().", ";
			}
		}
		
		$sender->sendMessage("§7► §eСписок §6донатеров§7:\n§7— §f".substr($list, 0, -2));
	}
}