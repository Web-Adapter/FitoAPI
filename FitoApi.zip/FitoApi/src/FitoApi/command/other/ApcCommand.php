<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use pocketmine\entity\Effect;

use FitoApi\Main;

class ApcCommand extends Command {
    
	public function __construct() {
		parent::__construct("apc");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("apc.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        if(isset(Main::getInstance()->apc[$sender->getLowerCaseName()])) return $sender->sendMessage("§7► §cДанная команда будет доступна после рестарта");
        
        Main::getInstance()->apc[$sender->getLowerCaseName()] = true;
        
        $sender->addEffect(Effect::getEffect(10)->setAmplifier(0)->setDuration(20 * 7));
        
        $sender->sendMessage("§7► §aТы съел §eзолотое яблоко");
	}
}