<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\{Player, Server};

use pocketmine\entity\Effect;

use FitoApi\Main;
use FitoApi\manager\EconomyManager as EconomyAPI;

class WhoisCommand extends Command {
    
	public function __construct() {
		parent::__construct("whois");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("whois.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        if(!isset($args[0]) or isset($args[1])) return $sender->sendMessage("§7► §eИспользование§7: §7/§6infop (никнейм");
        
        $targetPlayer = Server::getInstance()->getPlayer($args[0]);
        
        if($targetPlayer == null) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
        
        $clan = Main::getInstance()->clans->getClan($targetPlayer);

        $kills = !isset(Main::getInstance()->kills[strtolower($targetPlayer->getName())]) ? '0' : Main::getInstance()->kills[strtolower($targetPlayer->getName())];
		$death = Main::getInstance()->dea->get(strtolower($targetPlayer->getName())) === null ? '0' : Main::getInstance()->dea->get(strtolower($targetPlayer->getName()));
        
        if($clan == null) $clan = '§cотсутствует';

        $sender->sendMessage("§7► §eИнформация о игроке §a".$targetPlayer->getName() . "§7:" . "\n§7* §fЗашел: §e".Main::getInstance()->data->get($targetPlayer->getLowerCaseName())."\n§7* §fРежим§7: §a".Main::playerGetGamemode($targetPlayer)."\n§7* §fКлан§7: ".$clan."\n§7* §fПривилегия§7: §6".Main::getInstance()->groups->getUserDataMgr()->getGroup($targetPlayer)->getName()."\n§7* §fДенежные средства§7: §e".EconomyAPI::myMoney($targetPlayer) . "§6$" . "\n§7* §fУбийства§7: §e" . $kills . "\n§7* §fСмерти§7: §c" . $death);
	}
}