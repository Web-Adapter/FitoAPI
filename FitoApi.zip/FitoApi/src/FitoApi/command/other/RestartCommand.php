<?php

namespace FitoApi\command\other;

use pocketmine\Player;
use pocketmine\command\{Command, CommandSender};
use FitoApi\Main;
use FitoApi\utils\Helper;

class RestartCommand extends Command {
    
	public function __construct() {
		parent::__construct("restart");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if (in_array(strtolower($sender->getName()), Helper::ADMINS) or !$sender instanceof Player) {
            Main::$timeToRestart = 11;
        } else {
            $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        }
	}
}