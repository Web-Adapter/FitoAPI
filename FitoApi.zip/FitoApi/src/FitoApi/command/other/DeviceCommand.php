<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use FitoApi\Main;

class DeviceCommand extends Command {

    public function __construct() {
        parent::__construct("device", "Управление защитой устройства");
        $this->setDescription("Включает или выключает защиту по устройству.");
    }

    public function execute(CommandSender $sender, $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            return false;
        }

        if (count($args) !== 1) {
            return $this->sendUsage($sender);
        }

        $playerName = strtolower($sender->getName());
        $subCommand = strtolower($args[0]);

        switch ($subCommand) {
            case "on":
                return $this->enableDeviceProtection($sender, $playerName);
            case "off":
                return $this->disableDeviceProtection($sender, $playerName);
            default:
                return $this->sendUsage($sender);
        }
    }

    private function sendUsage(CommandSender $sender): bool {
        $sender->sendMessage("§7► §eИспользование§7: §7/§6device on§7/§6off§7›");
        return false;
    }

    private function enableDeviceProtection(Player $sender, string $playerName): bool {
        if (!Main::getInstance()->Config->exists($playerName)) {
            Main::getInstance()->Config->set($playerName, $sender->getDeviceModel());
            Main::getInstance()->Config->save();
            $sender->sendMessage("§7► §eЗащита по §6устройству §eуспешно §aвключена");
        } else {
            $sender->sendMessage("§7► §eЗащита по §6устройству §eуже включена");
        }
        return true;
    }

    private function disableDeviceProtection(Player $sender, string $playerName): bool {
        if (Main::getInstance()->Config->exists($playerName)) {
            Main::getInstance()->Config->remove($playerName);
            Main::getInstance()->Config->save();
            $sender->sendMessage("§7► §eЗащита по §6устройству §eуспешно §cвыключена");
        } else {
            $sender->sendMessage("§7► §eЗащита по §6устройству §eуже выключена");
        }
        return true;
    }
}