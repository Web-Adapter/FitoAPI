<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

class RepairAllCommand extends Command {
    
	public function __construct() {
		parent::__construct("repairall");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("repairall.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		$limit = $sender->getInventory()->getSize() + 4;
		for($items = 0; $items < $limit; ++$items){
		$item = $sender->getInventory()->getItem($items);
		if($item->getId() !== 373 and $item->getId() !== 374) $sender->getInventory()->setItem($items, $item->setDamage(0));
		}
        $sender->sendMessage("§7► §eТы успешно починил всю броню в инвентаре!");
	}
}