<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use pocketmine\item\enchantment\Enchantment;

class EnchantAllCommand extends Command {
    
	public function __construct() {
		parent::__construct("enchantall");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("enchantall.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		$limit = $sender->getInventory()->getSize() + 4;
		for($items = 0; $items < $limit; ++$items){
		$item = $sender->getInventory()->getItem($items);
		if($item->isArmor()){
		$enchantments = [0, 5, 1, 2, 3, 4];
		$en = $enchantments[array_rand($enchantments)];
		$item->addEnchantment(Enchantment::getEnchantment($en)->setLevel(rand(1, 5)));
		$sender->getInventory()->setItem($items, $item);
		}
		}
		$sender->getInventory()->setItem($items, $item->setDamage(0));
        $sender->sendMessage("§7► §eТы успешно рандомно зачаровал всю броню в инвентаре");
	}
}