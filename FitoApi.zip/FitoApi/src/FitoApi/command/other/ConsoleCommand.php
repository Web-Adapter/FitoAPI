<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};
use pocketmine\Player;
use FitoApi\Main;

class ConsoleCommand extends Command {

    public function __construct() {
        parent::__construct("console", "Управление доступом к консоли сервера.");
        $this->setPermission("console.cmd");
    }

    public function execute(CommandSender $sender, $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            return false;
        }

        if (!$sender->hasPermission("console.cmd")) {
            $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
            return false;
        }

        if (!isset(Main::getInstance()->snoopers[$sender->getName()])) {
            Main::getInstance()->snoopers[$sender->getName()] = $sender;
            $sender->sendMessage("§7► §eТы §aвключил §6консоль §eсервера!");
            return true;
        } else {
            unset(Main::getInstance()->snoopers[$sender->getName()]);
            $sender->sendMessage("§7► §eТы §cвыключил §6консоль §eсервера!");
            return true;
        }
    }
}