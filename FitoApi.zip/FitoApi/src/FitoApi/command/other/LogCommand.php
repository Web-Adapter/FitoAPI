<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;
use pocketmine\entity\{Wither, FallingSand, Vindicator, Villager, Human, WitherSkull2, Wither2, Evoker, WitherSkeleton2, Silverfish2, WitherGuardian, BigSkeleton};
use slapper\entities\{SlapperHuman, SlapperVillager, SlapperEvoker, SlapperWitherSkeleton};

class LogCommand extends Command {
    
	public function __construct() {
		parent::__construct("log");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("log.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		foreach($sender->getLevel()->getEntities() as $entity){
		if($entity instanceof Player or $entity instanceof SlapperHuman or $entity instanceof SlapperVillager or $entity instanceof Wither2 or $entity instanceof SlapperEvoker or $entity instanceof FallingSand or $entity instanceof Vindicator or $entity instanceof Villager or $entity instanceof SlapperWitherSkeleton or $entity instanceof Human or $entity instanceof Wither or $entity instanceof WitherSkull2 or $entity instanceof Evoker or $entity instanceof WitherSkeleton2 or $entity instanceof Silverfish2 or $entity instanceof WitherGuardian or $entity instanceof BigSkeleton) continue;
		$entity->close();
		}
        $sender->sendMessage("§7► §eТы очистил §6дроп §eна сервере!");
	}
}