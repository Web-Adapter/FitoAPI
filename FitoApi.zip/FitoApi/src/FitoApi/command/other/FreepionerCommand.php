<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender, ConsoleCommandSender};

use pocketmine\{Player, Server};

use FitoApi\Main;

class FreepionerCommand extends Command {
    
	public function __construct() {
		parent::__construct("freepioner");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
        $mainInstance = Main::getInstance();
        $playerName = $sender->getLowerCaseName();
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("freepioner.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        if(!isset($args[0]) or isset($args[1])) return $sender->sendMessage("§7► §eИспользование§7: §7/§6freepioner (никнейм)");
        
        if(isset($mainInstance->freeData['pioner'][$playerName])) return $sender->sendMessage("§7► §cТы уже выдал пионер в этом вайпе");
        
        $targetPlayer = Server::getInstance()->getPlayer($args[0]);
        
        if($targetPlayer == null) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
    
            
        $mainInstance->freeData['pioner'][$playerName] = true;

        Server::getInstance()->dispatchCommand(new ConsoleCommandSender(), "setgroup ".$targetPlayer->getLowerCaseName()." Pioner");
        
        $targetPlayer->sendMessage("§7► §eИгрок §a".$sender->getName()." §eвыдал тебе §6Пионер");
        
        $sender->sendMessage("§7► §eТы выдал игроку §a".$targetPlayer->getName()." §6Пионер");
	}
}