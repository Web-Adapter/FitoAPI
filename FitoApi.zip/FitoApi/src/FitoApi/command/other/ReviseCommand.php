<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use FitoApi\Main;

use pocketmine\Server;

class ReviseCommand extends Command {
    
	public function __construct() {
		parent::__construct("revise");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	   if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
      if(!$sender->hasPermission("revise.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset($args[0])) return $sender->sendMessage('§7► §eИспользование§7: §7/§6revise (никнейм)');
		$online = Server::getInstance()->getPlayer($args[0]);
		if(!$online) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
		if(strtolower($online->getName()) === strtolower($sender->getName())) return $sender->sendMessage('§7► §cТы не можешь остановить самого себя на проверку');
		Main::getInstance()->revise[$online->getLowerCaseName()] = true;
		$online->teleport($online->getLevel()->getSafeSpawn());
		$sender->teleport($online->asVector3()->add(0, 1, 1));
		$sender->sendMessage('§7► §cТы успешно остановил на проверку игрока §a'.$online->getName());
		$online->sendMessage('§7► §eИгрок§a '.$sender->getName().' §eостановил тебя на проверку, ты был телепортирован на §6спавн§e!');
		$online->addTitle('§cПРОВЕРКА!');
	}
}