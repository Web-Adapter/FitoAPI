<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use FitoApi\Main;

class RainBowCommand extends Command {
    
	public function __construct() {
		parent::__construct("rainbow");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
        if(!$sender->hasPermission("rainbow.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset(Main::getInstance()->armors[$sender->getLowerCaseName()])){
		Main::getInstance()->armors[$sender->getLowerCaseName()] = $sender;
        $sender->sendMessage("§7► §eТы §aвключил §eразноцветную броню!");
		}else{
		unset(Main::getInstance()->armors[$sender->getLowerCaseName()]);
		$sender->sendMessage("§7► §eТы §cотключил §eразноцветную броню!");
		}
	}
}