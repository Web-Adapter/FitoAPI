<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender};

use pocketmine\Player;

use FitoApi\Main;

use pocketmine\Server;

class UnReviseCommand extends Command{
    
	public function __construct() {
		parent::__construct("unrevise");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
	   if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
      if(!$sender->hasPermission("revise.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
		if(!isset($args[0])) return $sender->sendMessage('§7► §eИспользование§7: §7/§6unrevise (никнейм)');
		$online = Server::getInstance()->getPlayer($args[0]);
		if(!$online) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
		if(strtolower($online->getName()) === strtolower($sender->getName())) return $sender->sendMessage('§7► §cТы не можешь снять проверку с самого себя');
		if(!isset(Main::getInstance()->revise[$online->getLowerCaseName()])) return $sender->sendMessage('§7► §cИгрок не находится на проверке');
		unset(Main::getInstance()->revise[$online->getLowerCaseName()]);
		$sender->sendMessage('§7► §eТы успешно снял проверку с игрока §a'.$online->getName());
		$online->sendMessage('§7► §eИгрок §a'.$sender->getName().' §eуспешно снял проверку с тебя');
	}
}