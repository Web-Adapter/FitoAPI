<?php

namespace FitoApi\command\other;

use pocketmine\command\{Command, CommandSender, ConsoleCommandSender};

use pocketmine\{Player, Server};

use FitoApi\Main;

class FreeguardCommand extends Command {
    
	public function __construct() {
		parent::__construct("freeguard");
	}

	public function execute(CommandSender $sender, $commandLabel, array $args) {
        $mainInstance = Main::getInstance();
        $playerName = $sender->getLowerCaseName();
	    if(!$sender instanceof Player) return $sender->sendMessage("§7► §cКоманда предназначена исключительно для игроков");
            
        if(!$sender->hasPermission("freeguard.command")) return $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
        
        if(!isset($args[0]) or isset($args[1])) return $sender->sendMessage("§7► §eИспользование§7: §7/§6freeguard (никнейм)");
        
        if(isset($mainInstance->freeData['guard'][$playerName])) return $sender->sendMessage("§7► §cТы уже выдавал страж в этом вайпе");
        
        $targetPlayer = Server::getInstance()->getPlayer($args[0]);
        
        if($targetPlayer == null) return $sender->sendMessage("§7► §cИгрок §a".$args[0]." §cсейчас не в игре");
    
            
        $mainInstance->freeData['guard'][$playerName] = true;

        Server::getInstance()->dispatchCommand(new ConsoleCommandSender(), "setgroup ".$targetPlayer->getLowerCaseName()." Guard");
        
        $targetPlayer->sendMessage("§7► §eИгрок §a".$sender->getName()." §eвыдал тебе §bСтраж");
        
        $sender->sendMessage("§7► §eТы выдал игроку §a".$targetPlayer->getName()." §bСтраж");
	}
}