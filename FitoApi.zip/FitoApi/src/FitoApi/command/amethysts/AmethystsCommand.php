<?php

namespace FitoApi\command\amethysts;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use FitoApi\Main;
use FitoApi\manager\AmethystsManager;

class AmethystsCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct('amethysts', 'Просмотр баланса аметистов', null, ['myamethysts']);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $player, $label, array $args) {
        $playerName = strtolower($player->getName());

        $player->sendMessage("§8[§6Экономика§r§8] §eТвой баланс аметистов§7: §5" . AmethystsManager::myAmethysts($player) . ' §d');
    }
}