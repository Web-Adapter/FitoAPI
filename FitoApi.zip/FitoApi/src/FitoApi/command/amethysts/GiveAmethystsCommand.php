<?php

namespace FitoApi\command\amethysts;

use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use FitoApi\Main;
use FitoApi\manager\AmethystsManager;
use FitoApi\utils\Helper;

class GiveAmethystsCommand extends Command {

    private $plugin;

    public function __construct(Main $plugin) {
        parent::__construct('giveamethysts', 'Выдача игровой валюты');
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        $senderName = strtolower($sender->getName());
        
        if($sender instanceof Player && !in_array($senderName, Helper::ADMINS)) {
            $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
            return;
        }

        if(!isset($args[0]) or !isset($args[1]) or !is_numeric($args[1]) or $args[1] <= 0 or strpos($args[1], ".") !== false) {
            $sender->sendMessage("§7► §eИспользование§7: §7/§6giveamethysts (никнейм) (сумма)");
            return;
        } 

        $recipientName = $args[0];

        if(($recipient = $this->plugin->getServer()->getPlayer($args[0])) instanceof Player) {
            $recipient->sendMessage("§8[§6Экономика§r§8] §a" . $senderName  . " §eвыдал тебе §5" . $args[1] . ' §d');
            $recipientName = $recipient->getName();
        }

        AmethystsManager::addAmethysts($recipientName, $args[1]);

        $sender->sendMessage("§8[§6Экономика§r§8] §eТы успешно выдал игроку  §a" . $recipientName  . " §5" . $args[1] . ' §d');
    }
}