<?php

namespace FitoApi\manager;

class PvPManager {

	public static $playersInPvP = [];
	public static $lastDamager = [];

	public static function inPvP($player){
		return isset(self::$playersInPvP[$player->getName()]);
	}

	public static function updatePvPList($player){
		self::$playersInPvP[$player->getName()] = 30;
	}

	public static function removeFromPvP($player){
		unset(self::$playersInPvP[$player->getName()]);
	}

	public static function getCooldown($player){
		return self::$playersInPvP[$player->getName()];
	}

	public static function cooldownReduction($player){
		self::$playersInPvP[$player->getName()] = self::$playersInPvP[$player->getName()] - 1;
	}
}