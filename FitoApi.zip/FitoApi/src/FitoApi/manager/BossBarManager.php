<?php

namespace FitoApi\manager;

use pocketmine\Player;
use pocketmine\entity\Entity;
use FitoApi\utils\BossBarValues;
use FitoApi\Main;
use pocketmine\network\mcpe\protocol\{
	AddEntityPacket,
	BossEventPacket, 
	RemoveEntityPacket, 
	SetEntityDataPacket, 
	UpdateAttributesPacket
};

class BossBarManager {

	public static $entityRuntimeId = null;

	public static function sendBossBarToPlayer($player, $text, $id){
		$packet = new AddEntityPacket();
		$packet->type = 37;
		$packet->eid = $id;
		$packet->position = $player->getPosition()->asVector3()->subtract(0, 28);
		$packet->metadata = [Entity::DATA_NAMETAG => [Entity::DATA_TYPE_STRING, $text], Entity::DATA_FLAGS => [Entity::DATA_TYPE_LONG, 0 ^ 1 << Entity::DATA_FLAG_SILENT ^ 1 << Entity::DATA_FLAG_INVISIBLE ^ 1 << Entity::DATA_FLAG_NO_AI]];
		$player->dataPacket($packet);
		$bpk = new BossEventPacket();
		$bpk->eid = $id;
		$player->dataPacket($bpk);
	}

	public static function setTitleBossBar($player, $text, $id){
		$packet = new SetEntityDataPacket();
		$packet->eid = $id;
		$packet->metadata = [Entity::DATA_NAMETAG => [Entity::DATA_TYPE_STRING, $text]];
		$player->dataPacket($packet);
		$bpk = new BossEventPacket();
		$bpk->bossEid = $id;
		$player->dataPacket($bpk);
	}

	public static function setProgressBossBar($player, $id, $healthPercent){
		$upk = new UpdateAttributesPacket();
		$upk->entries[] = new BossBarValues(1, 600, max(1, min([$healthPercent * 100, 100])) / 100 * 600, 'minecraft:health');
		$upk->entityId = $id;
		$player->dataPacket($upk);
		$bpk = new BossEventPacket();
		$bpk->eid = $id;
		$bpk->healthPercent = $healthPercent;
		$player->dataPacket($bpk);
	}

}