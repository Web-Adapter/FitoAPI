<?php

namespace FitoApi\manager;

use pocketmine\Server;
use pocketmine\Player;
use FitoApi\Main;

class EconomyManager {

	public static function addMoney($player, int $money) {
		if(is_string($player)) {
			if(!Main::$money->exists(strtolower($player))) {
            	Main::$money->set(strtolower($player), 0);
            	Main::$money->save();
        	}

			Main::$money->set(strtolower($player), Main::$money->get(strtolower($player)) + $money);
		} else {
			if(!Main::$money->exists(strtolower($player->getName()))) {
            	Main::$money->set(strtolower($player->getName()), 0);
            	Main::$money->save();
        	}

			Main::$money->set(strtolower($player->getName()), Main::$money->get(strtolower($player->getName())) + $money);
		}

		Main::$money->save();
	}
	
	public static function reduceMoney($player, int $money) {
		if(is_string($player)) {
			Main::$money->set(strtolower($player), Main::$money->get(strtolower($player)) - $money);
		} else {
			Main::$money->set(strtolower($player->getName()), Main::$money->get(strtolower($player->getName())) - $money);
		}

		Main::$money->save();
	}

	public static function myMoney($player) {
		if(is_string($player)) {
			return Main::$money->get(strtolower($player));
		} else {
			return Main::$money->get(strtolower($player->getName()));
		}
	}
}