<?php

namespace FitoApi\manager;

use pocketmine\Server;
use pocketmine\Player;
use FitoApi\Main;

class AmethystsManager {

	public static function addAmethysts($player, int $amethysts) {
		if(is_string($player)) {
			if(!Main::$amethysts->exists(strtolower($player))) {
            	Main::$amethysts->set(strtolower($player), 0);
            	Main::$amethysts->save();
        	}

			Main::$amethysts->set(strtolower($player), Main::$amethysts->get(strtolower($player)) + $amethysts);
		} else {
			if(!Main::$amethysts->exists(strtolower($player->getName()))) {
            	Main::$amethysts->set(strtolower($player->getName()), 0);
            	Main::$amethysts->save();
        	}

			Main::$amethysts->set(strtolower($player->getName()), Main::$amethysts->get(strtolower($player->getName())) + $amethysts);
		}

		Main::$amethysts->save();
	}
	
	public static function reduceAmethysts($player, int $amethysts) {
		if(is_string($player)) {
			Main::$amethysts->set(strtolower($player), Main::$amethysts->get(strtolower($player)) - $amethysts);
		} else {
			Main::$amethysts->set(strtolower($player->getName()), Main::$amethysts->get(strtolower($player->getName())) - $amethysts);
		}

		Main::$amethysts->save();
	}

	public static function myAmethysts($player) {
		if(is_string($player)) {
			return Main::$amethysts->get(strtolower($player));
		} else {
			return Main::$amethysts->get(strtolower($player->getName()));
		}
	}
}