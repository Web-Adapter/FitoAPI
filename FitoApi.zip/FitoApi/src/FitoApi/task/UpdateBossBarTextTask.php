<?php

namespace FitoApi\task;

use pocketmine\scheduler\Task;
use pocketmine\Player;
use FitoApi\Main;
use FitoApi\manager\BossBarManager;
use FitoApi\manager\PvPManager;
use FitoApi\utils\Helper;
use tempist\bosses\Main as BossEvent;
use tempist\mevent\task\UpdateEventTask;

class UpdateBossBarTextTask extends Task {

	private $plugin;

	private $eventCounters = [
        'drop' => 0,
        'boss' => 0,
        'airdrop' => 0,
        'goldrush' => 0,
        'mevent' => 0
    ];

    private $event = 'drop';
    private $currentEventIndex = 0;

	function __construct(Main $plugin) {
		$this->plugin = $plugin;
	}

	public function onRun($currentTick) {
		if (BossBarManager::$entityRuntimeId === null) {
			return;
		} 

		foreach($this->plugin->getServer()->getOnlinePlayers() as $player){
			if (PvPManager::inPvP($player)) {
				$cooldown = PvPManager::getCooldown($player);
				# $opponentName = PvPManager::$lastDamager[$player->getName()];

				/* if(($opponent = $this->plugin->getServer()->getPlayer($opponentName)) instanceof Player){
					$opponentPing = $opponent->getPing();
				} else {
					$opponentPing = 0;
				} */

				$line1 = "§7⚔ §c§lPvP-Режим§r§f активен, до деактивации осталось §6" . round($cooldown) . " §eс. §r§7⚔\n\n";
				# $line2 = "      §fТекущий противник§8: §c" . $opponentName . " §7(" . $opponentPing . " ms)        ";

				BossBarManager::setProgressBossBar($player, BossBarManager::$entityRuntimeId, 1 - ($cooldown / 30));
				BossBarManager::setTitleBossBar($player, 
					$line1
					# . $line2
					, BossBarManager::$entityRuntimeId);
				
				continue;
			}	

			$events = [];

    		if($this->plugin->dropEvent->delay["int"] !== 2) {
    			if ($this->plugin->dropEvent->countdownSeconds > 0) {
        			$events['drop'] = "§6§lРаздача на спавне §r§eначнется через " . $this->convertToMinutesAndSeconds($this->plugin->dropEvent->countdownSeconds);
        			$events['drop progress'] = (660 - $this->plugin->dropEvent->countdownSeconds) / 660;
    			} else  {
    				$events['drop'] = "§6§lРаздача на спавне §r§eначалась!";
    				$events['drop progress'] = 1;
    			}
    		}

    		if (!BossEvent::$bossSpawned && $this->plugin->bossEvent->timer > 0) {
        		$events['boss'] = BossEvent::$rarity . " §6Босс §r§eпоявится через " . $this->convertToMinutesAndSeconds($this->plugin->bossEvent->timer);
        		$events['boss progress'] = (1380 - $this->plugin->bossEvent->timer) / 1380;
    		} elseif (BossEvent::$bossSpawned) {
    			$events['boss'] = BossEvent::$rarity . " §6Босс §r§eпоявился на арене!";
    			$events['boss progress'] = 1;
    		}

    		if (!$this->plugin->airDrop->isActive) {
        		$events['airdrop'] = $this->plugin->airDrop->rarity . " §6Аирдроп §eпоявится через " . $this->convertToMinutesAndSeconds($this->plugin->airDrop->ticksMax - $this->plugin->airDrop->ticks);
        		$events['airdrop progress'] = $this->plugin->airDrop->ticks / $this->plugin->airDrop->ticksMax;
    		} else {
    			[$x, $y, $z] = $this->plugin->airDrop->chestCoordinates;
    			$events['airdrop'] = $this->plugin->airDrop->rarity . " §6Аирдроп §eна координатах§7: §a" . $x . "§7, §a" . $y . "§7, §a" . $z;
    			$events['airdrop progress'] = 1;
    		}

    		if ($this->plugin->goldRush->timeGoldRushStarts > 0) {
        		$events['goldrush'] = "§6§lЗолотая лихорадка §r§eначнет действовать через " . $this->convertToMinutesAndSeconds($this->plugin->goldRush->timeGoldRushStarts);
        		$events['goldrush progress'] = (1800 - $this->plugin->goldRush->timeGoldRushStarts) / 1800;
    		} elseif ($this->plugin->goldRush->goldRushActive) {
    			$events['goldrush'] = "§6§lЗолотая лихорадка §r§eдействует у §a§lСкупщика§r§e!";
    			$events['goldrush progress'] = 1;
    		}

    		if (!$this->plugin->mevent->getEventManager()->getStatus()) {
    			$events['mevent'] = "§d§lКосмический Король §r§eвернется через " . $this->convertToMinutesAndSeconds(1200 - UpdateEventTask::$countSeconds);
    			$events['mevent progress'] = UpdateEventTask::$countSeconds / 1200;
    		} else {
    			$events['mevent'] = "§d§lКосмический Король §r§eвернулся!";
    			$events['mevent progress'] = 1;
    		}

    		if ($this->eventCounters[$this->event] >= 5) {
    			$this->eventCounters[$this->event] = 0;
    			$this->event = $this->getNextEvent();
    		}

    		while (!isset($events[$this->event])) {
    			$this->event = $this->getNextEvent();
    		}

    		BossBarManager::setTitleBossBar($player, $events[$this->event], BossBarManager::$entityRuntimeId);
    		BossBarManager::setProgressBossBar($player, BossBarManager::$entityRuntimeId, $events[$this->event . ' progress']);
		}

		$this->eventCounters[$this->event]++;
	}

	function convertToMinutesAndSeconds($totalSeconds) {
    	$minutes = floor($totalSeconds / 60);
    	$seconds = $totalSeconds % 60;

    	$formattedTime = "§a" . $minutes . " §eм. §a" . $seconds . " §eсек.";

    	return $formattedTime;
	}

	function getNextEvent() {
		$eventOrder = ['airdrop', 'drop', 'boss', 'goldrush', 'mevent'];

		if ($this->currentEventIndex == 4) {
			$this->currentEventIndex = 0;
		} else {
			$this->currentEventIndex = $this->currentEventIndex + 1;
		}
		
    	return $eventOrder[$this->currentEventIndex];
	}
}