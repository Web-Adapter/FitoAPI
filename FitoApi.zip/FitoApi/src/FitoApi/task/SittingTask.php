<?php

namespace FitoApi\task;

use pocketmine\scheduler\Task;

class SittingTask extends Task {

    private $plugin;
    private $targetPlayer;
    private $sitEntity;
    private $senderName;

    public function __construct($plugin, $targetPlayer, $sitEntity, $sender) {
        $this->plugin = $plugin;
        $this->targetPlayer = $targetPlayer;
        $this->sitEntity = $sitEntity;
        $this->senderName = $sender->getName();
    }

    public function onRun($currentTick) {
        if (!isset($this->plugin->sitPlayers[$this->senderName])) $this->getHandler()->cancel();
        $this->plugin->teleportSitEntityToTargetPlayer($this->targetPlayer, $this->sitEntity);
    }    
}