<?php

namespace FitoApi\task;

use FitoApi\Main;
use pocketmine\scheduler\PluginTask;

class ArmorColorsTask extends PluginTask{
	
	public $owner;

	public function __construct(Main $owner){
		$this->owner = $owner;
	}

	public function onRun($tick){
		$this->owner->randomArmorColors();
	}
}