<?php

namespace FitoApi\task;

use pocketmine\scheduler\Task;
use FitoApi\Main;
use FitoApi\manager\PlayerManager;
use pocketmine\command\ConsoleCommandSender;
use FitoApi\manager\PvPManager;
use FitoApi\utils\Helper;

class RestartTask extends Task {

	private $plugin;
	private $value = false;

	function __construct(Main $plugin) {
		$this->plugin = $plugin;
	}

	public function onRun($currentTick) {
        Main::$timeToRestart--;

        $timesToAnnounce = [
            90 * 60 => "Через §a1 §eчас §a30 §eминут §6перезагрузка §eсервера!",
            80 * 60 => "Через §a1 §eчас §a20 §eминут §6перезагрузка §eсервера!",
            70 * 60 => "Через §a1 §eчас §a10 §eминут §6перезагрузка §eсервера!",
            60 * 60 => "Через §a1 §eчас §6перезагрузка §eсервера!",
            50 * 60 => "Через §a50 §eминут §6перезагрузка §eсервера!",
            40 * 60 => "Через §a40 §eминут §6перезагрузка §eсервера!",
            30 * 60 => "Через §a30 §eминут §6перезагрузка §eсервера!",
            20 * 60 => "Через §a20 §eминут §6перезагрузка §eсервера!",
            10 * 60 => "Через §a10 §eминут §6перезагрузка §eсервера!",
            5 * 60  => "Через §a5 §eминут §6перезагрузка §eсервера!",
            1 * 60  => "Через §a1 §eминуту §6перезагрузка §eсервера!",
            10      => "Через §a10 §eсекунд §6перезагрузка §eсервера! Ты будешь перенаправлен в лобби!"
        ];

        foreach ($timesToAnnounce as $time => $message) {
            if (Main::$timeToRestart == $time) {
                $this->plugin->getServer()->broadcastMessage("§7► §e{$message}");

                break;
            }


        }

         if (Main::$timeToRestart <= 10) {
            foreach($this->plugin->getServer()->getOnlinePlayers() as $player) {
                Main::sendSound($player, 'random.orb');
                $color = $this->getColorForTime(Main::$timeToRestart);
                $player->addTitle("{$color}§l" . Main::$timeToRestart . "§r", "§7Подготовка к перезагрузке!");
            }

            if (Main::$timeToRestart == 0) {
                $this->restartServer();
            }
        }
    }

    private function getColorForTime($time) {
        if($time > 5) return "§a";
        if($time > 3) return "§e";
        if($time == 3) return "§6";
        if($time == 2) return "§c";
        if($time == 1) return "§4";
    }

    private function restartServer() {
        foreach($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (PvPManager::inPvP($player)){
                PvPManager::removeFromPvP($player);
            } 

            $player->transfer('play.cosmixpe.ru', 19132);
        }

        $this->plugin->getServer()->dispatchCommand(new ConsoleCommandSender(), "save-all");
        $this->plugin->getServer()->shutdown();
    }
}
