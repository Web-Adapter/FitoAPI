<?php

namespace FitoApi\task;

use pocketmine\scheduler\Task;
use FitoApi\Main;
use FitoApi\manager\PvPManager;
use FitoApi\manager\PlayerManager;
use FitoApi\utils\Helper;

class UpdatePvPTask extends Task {

	private $plugin;

	function __construct(Main $plugin) {
		$this->plugin = $plugin;
	}

	public function onRun($currentTick) {
		foreach(PvPManager::$playersInPvP as $playerName => $value){
			$player = $this->plugin->getServer()->getPlayer($playerName);

			PvPManager::cooldownReduction($player);

			if(PvPManager::getCooldown($player) <= 0){
				PvPManager::removeFromPvP($player);
				$player->sendMessage("§8[§6PvP-Режим§8] §eРежим деактивирован!");
				$player->sendTitle("", "§7PvP-Режим деактивирован!");	
			}
		}
	}
}
