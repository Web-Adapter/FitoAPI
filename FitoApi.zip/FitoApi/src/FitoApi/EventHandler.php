<?php

namespace FitoApi;

use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\ {
    Item, Armor
};
use pocketmine\entity\Villager;
use pocketmine\entity\Entity;
use pocketmine\level\Position;
use pocketmine\event\inventory\InventoryCloseEvent;
use pocketmine\network\mcpe\protocol\StopSoundPacket;
use pocketmine\event\player\ {
    PlayerJoinEvent, PlayerMoveEvent, PlayerDeathEvent, PlayerRespawnEvent, PlayerInteractEvent, PlayerQuitEvent, PlayerKickEvent, PlayerChatEvent, PlayerItemConsumeEvent, PlayerDropItemEvent
};
use pocketmine\event\entity\ {
    ProjectileLaunchEvent, EntityExplodeEvent, EntityDamageEvent, EntityDamageByEntityEvent
};
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\block\ {
    ItemFrameDropItemEvent, BlockBreakEvent, BlockPlaceEvent
};

use pocketmine\event\block\BlockUpdateEvent;

use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\scheduler\CallbackTask;

use FitoApi\Main;
use FitoApi\utils\Helper;
use FitoApi\manager\BossBarManager;
use FitoApi\manager\EconomyManager as EconomyAPI;
use pocketmine\inventory\EnderChestInventory;
use pocketmine\math\Vector3;

use pocketmine\network\mcpe\protocol\AnimatePacket;

use pocketmine\event\block\SignChangeEvent;

use FitoApi\manager\PvPManager;

use pocketmine\level\particle\WhiteSmokeParticle;

use Auth\Main as Auth;

use pocketmine\nbt\tag\{CompoundTag, IntTag, ListTag, StringTag, DoubleTag, FloatTag, ShortTag};

use pocketmine\event\level\ChunkLoadEvent;
use pocketmine\event\level\ChunkPopulateEvent;

use tempist\mine\MineGenerator;

class EventHandler implements Listener {
    private static $cooldownUse = [];
    private $cooldowns = [];
    private $fitoApi;
    private $auth;
    private $rg;

    public function __construct(Main $plugin) {
        $this->auth = Server::getInstance()->getPluginManager()->getPlugin('Auth');
        $this->rg = Server::getInstance()->getPluginManager()->getPlugin('Regions');
        $this->fitoApi = $plugin;
    }

    public function chunkPopulate(ChunkPopulateEvent $event) {
        if ($event->getLevel()->getFolderName() == 'spawn') {
            $event->getChunk()->setAllBlockSkyLight(15);
        } 
    }

    public function chunkLoad(ChunkLoadEvent $event) {
        if ($event->getLevel()->getFolderName() == 'spawn') {
            $event->getChunk()->setAllBlockSkyLight(15);
        } 
    }

    public function onCreateSign(SignChangeEvent $event){
        if($event->isCancelled()) {
           return; 
        } 

        if($event->getLine(0) == 'DonateCase'){
            $event->setLines(["§8[§d§lDONATE-CASE§r§8]", "§fcosmixpe.ru", "", ""]);
            return;
        }

        if($event->getLine(0) == 'DropCase'){
            $event->setLines(["§8[§a§lDROP-CASE§r§8]", "§fcosmixpe.ru", "", ""]);
            return;
        }

        if($event->getLine(0) == 'MoneyCase'){
            $event->setLines(["§8[§e§lMONEY-CASE§r§8]", "§fcosmixpe.ru", "", ""]);
            return;
        }

        if($event->getLine(0) == 'ClanCase'){
            $event->setLines(["§8[§1§lCLAN-CASE§r§8]", "§7Используй - /cw", "", ""]);
            return;
        }

        if($event->getLine(0) == 'MythicCase'){
            $event->setLines(["§8[§5§lMYTHIC-CASE§r§8]", "§fКлюч падает с босса", "", ""]);
            return;
        }

        if($event->getLine(0) == 'PvPCase'){
            $event->setLines(["§8[§6§lPvP-CASE§r§8]", "§fСтоимость§7: §e2.500§6$", "", ""]);
            return;
        }

        if($event->getLine(0) == 'KitCase'){
            $event->setLines(["§8[§9§lKIT-CASE§r§8]", "§fСтоимость§7: §e10.000§6$", "", ""]);
            return;
        }

        if($event->getLine(0) == 'BonusCase'){
            $event->setLines(["§8[§a§lBONUS-CASE§r§8]", "§e1200§6\$§7-§e3300§6\$", "", ""]);
            return;
        }
    }

    public function onCloseInventory(InventoryCloseEvent $e){
        if ($e->getInventory() instanceof EnderChestInventory) {
            $this->fitoApi->deleteChest($e->getPlayer());
        }
    }

    public function handleInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $playerName = strtolower($player->getName());

        $item = $player->getItemInHand();
        $itemId = $item->getId();

        $block = $event->getBlock();
        $blockId = $block->getId();

        if ($player->getLevel()->getFolderName() !== 'world') {
            if ($blockId == 54 or $blockId == 218) {
                if (MineGenerator::isBlockInMine($block->getX(), $block->getY(), $block->getZ()) and $player->getLevel()->getFolderName() == 'spawn') {
                    return;
                }

                $event->setCancelled();
            }
        }

        if ($player->isSurvival()) {
            if ($event->getAction() == PlayerInteractEvent::RIGHT_CLICK_AIR) {
                if ($itemId == 368) {
                    $currentTime = time();

                    if (isset(self::$cooldownUse[368][$playerName])) {
                        $remainingTime = self::$cooldownUse[368][$playerName] - $currentTime;

                        if ($remainingTime <= 0) {
                            if (!$player->hasPermission('cooldown.reduction')){
                                self::$cooldownUse[368][$playerName] = $currentTime + 46;
                            } else {
                                self::$cooldownUse[368][$playerName] = $currentTime + 30;
                            }

                            return;
                        }

                        $event->setCancelled();
                        $player->addTitle("", "§7Подожди " . Helper::convertTimeOptimized(self::$cooldownUse[368][$playerName] - $currentTime));
                    } else {
                        if (!$player->hasPermission('cooldown.reduction')){
                            self::$cooldownUse[368][$playerName] = $currentTime + 46;
                        } else {
                            self::$cooldownUse[368][$playerName] = $currentTime + 30;
                        }
                    }
                }
            }
        }
    }

    public function handleEat(PlayerItemConsumeEvent $event){
        $player = $event->getPlayer();
        $playerName = strtolower($player->getName());

        $item = $event->getItem();
        $itemId = $item->getId();

        $currentTime = time();

        if($player->hasPermission('cooldown.reduction')){
            $cooldownTimes = [
                322 => 41, // Золотое яблоко
                466 => 211, // Зачарованное золотое яблоко
                432 => 21, // Плод хоруса
            ];
        } else {
            $cooldownTimes = [
                322 => 61, // Золотое яблоко
                466 => 301, // Зачарованное золотое яблоко
                432 => 31, // Плод хоруса
            ];
        }

        if(isset($cooldownTimes[$itemId])){
            $itemType = array_search($cooldownTimes[$itemId], $cooldownTimes);
            if(isset(self::$cooldownUse[$itemType][$playerName])){
                $remainingTime = self::$cooldownUse[$itemType][$playerName] - $currentTime;

                if ($remainingTime <= 0) {
                    self::$cooldownUse[$itemType][$playerName] = $currentTime + $cooldownTimes[$itemId];
                    return;
                }

                $event->setCancelled();
                $player->addTitle("", "§7Подожди " . Helper::convertTimeOptimized($remainingTime));
            } else {
                self::$cooldownUse[$itemType][$playerName] = $currentTime + $cooldownTimes[$itemId];
            }
        } 
    }

    public function onUpdate(BlockUpdateEvent $event){
        if ($event->getBlock()->getId() == 8 || 9 || 10 || 11) {
            $event->setCancelled(true);
        }
    }

    public function PlayerJoin2(PlayerJoinEvent $event) {
        $event->setJoinMessage(null);

        $this->fitoApi->data->set($event->getPlayer()->getLowerCaseName(), date("h:i:s"));
        if (isset($this->fitoApi->sozd[$event->getPlayer()->getLowerCaseName()])) Server::getInstance()->broadcastMessage('§7► §eНа сервер зашел §a' . $event->getPlayer()->getName());
        if (!$event->getPlayer()->hasPermission('fapi.cmd.gm') and !isset($this->fitoApi->freegm[$event->getPlayer()->getLowerCaseName()])) $event->getPlayer()->setGamemode(0);
    }

    public function PlayerQuit2(PlayerQuitEvent $event) {
        $event->setQuitMessage(null);

        if (isset($this->fitoApi->armors[$event->getPlayer()->getLowerCaseName()])) unset($this->fitoApi->armors[$event->getPlayer()->getLowerCaseName()]);
        if (isset($this->fitoApi->freeze[$event->getPlayer()->getLowerCaseName()])) unset($this->fitoApi->freeze[$event->getPlayer()->getLowerCaseName()]);
        if (isset($this->fitoApi->freegm[$event->getPlayer()->getLowerCaseName()])) $event->getPlayer()->setGamemode(0);
    }

    public function PlayerMove2(PlayerMoveEvent $event) {
        $player = $event->getPlayer();

        if ($player->getLevel()->getFolderName() == 'spawn') {
            if ($player->getY() < 0) {
                $player->teleport(new Vector3(-51, 39, -6));
            }
        }

        foreach ($player->getLevel()->getEntities() as $entity) {
            if (strpos($entity->getNameTag(), "§6АРЕНА") or strpos($entity->getNameTag(), "§aМИР ВЫЖИВАНИЯ") or $entity->getNameTag() == '§7soon..') {
                if ($player->distance($entity->getPosition()) < 1) {
                    $direction = $player->getDirectionVector();

                    $motionX = $direction->x * -1;
                    $motionY = 0.5;
                    $motionZ = $direction->z * -1;

                    $player->setMotion(new Vector3($motionX / 6, $motionY, $motionZ / 6));
                }
            }
        }

        if (isset($this->fitoApi->freeze[$event->getPlayer()->getLowerCaseName()])) $event->setCancelled();
        if (isset($this->fitoApi->revise[$event->getPlayer()->getLowerCaseName()])) {
            $event->getPlayer()->sendTitle('§сВЫ НА ПРОВЕРКЕ!');
            $event->setCancelled();
        }
    }

    public function handleEntityDamage1(EntityDamageEvent $event){
        if(!$event instanceof EntityDamageByEntityEvent){
            return;
        }

        $player = $event->getDamager();
        $entity = $event->getEntity();

        if ($player instanceof Player && strpos($entity->getNameTag(), "§6АРЕНА") !== false) {
            $event->setCancelled();

            if ($player->getGamemode() !== 0) {
                $player->sendMessage("§7► §cТы должен находиться в режиме Выживания");
                return false;
            }

            $player->setAllowFlight(false);
            $player->setFlying(false);

            $pk = new AnimatePacket();
            $pk->action = AnimatePacket::ACTION_CRITICAL_HIT;
            $pk->eid = $entity->getId();
            Server::getInstance()->broadcastPacket($entity->getViewers(), $pk);

            $player->sendTitle('§6§lАрена§r', '§7Телепортация..');
            $player->teleport(Server::getInstance()->getLevelByName('pvparena')->getSafeSpawn());
        }
    }

    public function handleEntityDamage2(EntityDamageEvent $event){
        if(!$event instanceof EntityDamageByEntityEvent){
            return;
        }

        $player = $event->getDamager();
        $entity = $event->getEntity();

        if ($player instanceof Player && strpos($entity->getNameTag(), "§aМИР ВЫЖИВАНИЯ") !== false) {
            $event->setCancelled();

            $pk = new AnimatePacket();
            $pk->action = AnimatePacket::ACTION_CRITICAL_HIT;
            $pk->eid = $entity->getId();
            Server::getInstance()->broadcastPacket($entity->getViewers(), $pk);

            $player->sendTitle('§a§lМир Выживания§r', '§7Телепортация..');
            $player->teleport(Server::getInstance()->getLevelByName('world')->getSafeSpawn());
        }
    }

    public function handleEntityDamage3(EntityDamageEvent $event){
        if(!$event instanceof EntityDamageByEntityEvent){
            return;
        }

        $player = $event->getDamager();
        $entity = $event->getEntity();

        if ($player instanceof Player && $entity->getNameTag() == '§7soon..') {
            $event->setCancelled();

            $pk = new AnimatePacket();
            $pk->action = AnimatePacket::ACTION_CRITICAL_HIT;
            $pk->eid = $entity->getId();
            Server::getInstance()->broadcastPacket($entity->getViewers(), $pk);

            $player->sendMessage('§7► §eДанный §6NPC §eпоявится в скором время!');
        }
    }

        public function onDamage(EntityDamageEvent $e) {
        if (!($p = $e->getEntity()) instanceof Player) return;

        if ($p->getLevel()->getFolderName() == 'spawn') {
            $e->setCancelled();
            return;
        }

        if ($e->getCause() === EntityDamageEvent::CAUSE_FALL) {
            if ($p->getGamemode() == 1 || (isset(Main::$god[$p->getName()]) && Main::$god[$p->getName()])) $e->setCancelled(true);
        }

        if ($e instanceof EntityDamageByEntityEvent) {
            if (!($d = $e->getDamager()) instanceof Player or $e->isCancelled()) return;
            if ($d->getName() == $p->getName()) return $e->setCancelled(true);
            if (isset(Main::$vanish[$d->getName()]) && Main::$vanish[$d->getName()]) {
                $e->setCancelled(true);
                $d->sendPopup("§cНевозможно атаковать в режиме §6Слежки§e!");
                return;
            }

            if (isset(Main::$vanish[$p->getName()]) && Main::$vanish[$p->getName()]) {
                $e->setCancelled(true);
                return;
            }

            if (isset(Main::$god[$d->getName()]) && Main::$god[$d->getName()]) {
                $e->setCancelled(true);
                $d->sendPopup("§cНевозможно атаковать в §eрежиме §6Бога§c!");
                return;
            }

            if (isset(Main::$god[$p->getName()]) && Main::$god[$p->getName()]) {
                $e->setCancelled(true);
                $d->sendPopup("§cУ игрока §a" . $p->getName() . "§c активен §eрежим §6Бога§e!");
                return;
            }

            if (isset(Main::$size[$p->getName()]) && Main::$size[$p->getName()]) {
                $e->setCancelled(true);
                $d->sendPopup("§cУ игрока §a" . $p->getName() . "§c другой §6размер§e!");
                return;
            }

            if (isset(Main::$size[$d->getName()]) && Main::$size[$d->getName()]) {
                $e->setCancelled(true);
                $d->sendPopup("§cНевозможно атаковать в другом §6размере§e!\n\n");
                return;
            }

            if ($d->isCreative()) {
                $e->setCancelled(true);
                $d->sendPopup("§cНевозможно атаковать в §6Креативе§c!");
                return;
            }

            if ($d->getAllowFlight() and !$d->isCreative()) {
                $e->setCancelled(true);
                $d->sendPopup("§cНевозможно атаковать в §eрежиме §6Полёта§c!");
                return;
            }

            if ($p->getAllowFlight() and !$p->isCreative()) {
                $e->setCancelled(true);
                $d->sendPopup("§cУ игрока §a" . $p->getName() . "§c активен §eрежим §6Полёта§c!");
                return;
            }

            $playerDevice = $d->getDeviceOs();

            if ($playerDevice != 1 and $playerDevice != 2) {
                $e->setDamage($e->getDamage() / 2);
            }

            return true;
        }
    }

    public function PlayerDamage2(EntityDamageEvent $event) {
        if ($event->isCancelled()) {
            return;
        }

        $entity = $event->getEntity();

        if ($entity instanceof Player) {
            if ($entity->getInventory()->getChestPlate()->getId() == 444) {
                if ($event->getCause() == EntityDamageEvent::CAUSE_FALL) {
                    $event->setCancelled();
                }
            }
        }

        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if (!$damager instanceof Player or !$entity instanceof Player) return;

            $data = Main::$gameTime->getAll();

            if (isset($data[($damagerName = strtolower($damager->getName()))])) {
                if ($data[$damagerName] < 600) {
                    $damager->sendPopup('§cТебе нужно наиграть еще ' . Helper::convertTimeOptimized(600 - $data[$damagerName]));
                    $event->setCancelled();
                    return;
                }
            }

            if (isset($data[($entityName = strtolower($entity->getName()))])) {
                if ($data[$entityName] < 600) {
                    $damager->sendPopup('§cИгроку нужно наиграть еще ' . Helper::convertTimeOptimized(600 - $data[$entityName]));
                    $event->setCancelled();
                    return;
                }
            }

            if (isset($this->fitoApi->freeze[$damager->getLowerCaseName()]) or isset($this->fitoApi->freeze[$entity->getLowerCaseName()]) or isset($this->fitoApi->revise[$damager->getLowerCaseName()]) or isset($this->fitoApi->revise[$entity->getLowerCaseName()])) $event->setCancelled();

            if ($damager->getLevel()->getFolderName() == 'pvparena' or $damager->getLevel()->getFolderName() == 'eventWorld' or $damager->getLevel()->getFolderName() == 'world') {
                if (!$this->auth->isLogined($entity->getName()) or !$this->auth->isLogined($damager->getName())) {
                    return;
                }

                if (($region = $this->rg->getRegion($entity->getPosition())) !== null) {
                    if ($region->getFlagValue('pvp') == false) {
                        return;
                    }
                }

                PvPManager::$lastDamager[$entity->getName()] = $damager->getName();
                PvPManager::$lastDamager[$damager->getName()] = $entity->getName();

                if(!PvPManager::inPvP($damager)){
                    $damager->sendMessage("§8[§6PvP-Режим§8] §eРежим активирован!");
                    $damager->addTitle("", "§7PvP-Режим активирован!");
                    Main::sendSound($damager, 'mob.elderguardian.idle');
                    $damager->getLevel()->addParticle(new WhiteSmokeParticle(new Vector3($damager->getX(), $damager->getY(), $damager->getZ())));
                }

                PvPManager::updatePvPList($damager);

                if(!PvPManager::inPvP($entity)){
                    $entity->sendMessage("§8[§6PvP-Режим§8] §eРежим активирован!");
                    $entity->addTitle("", "§7PvP-Режим активирован!");
                    Main::sendSound($entity, 'mob.elderguardian.idle');
                    $entity->getLevel()->addParticle(new WhiteSmokeParticle(new Vector3($entity->getX(), $entity->getY(), $entity->getZ())));
                }

                PvPManager::updatePvPList($entity);
            }
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {
        $quittingPlayer = $event->getPlayer();
        $quittingPlayerName = $quittingPlayer->getName();

        if(PvPManager::inPvP($quittingPlayer)){
            PvPManager::removeFromPvP($quittingPlayer);
            $quittingPlayer->kill();
        }

        if (!empty($this->fitoApi->sitPlayers)) {
            if (isset($this->fitoApi->sitPlayers[$quittingPlayerName])) {
                $targetName = $this->fitoApi->getTargetName($quittingPlayerName);
                $this->fitoApi->standUp($quittingPlayer, $targetName);
            }
        }
    }

    public function PlayerDropItem(PlayerDropItemEvent $event) {
        if ($event->getPlayer()->getGamemode() != 0) {
            $event->setCancelled();
        }
    }

    public function PlayerInteract2(PlayerInteractEvent $event) {
        $player = $event->getPlayer();

        $playerName = $player->getLowerCaseName();

        $block = $event->getBlock();
        $id = $block->getId();
        if ($id == 54 or $id == 154 or $id == 146 or $id == 61 or $id == 117 or $id == 130 or $id == 125 or $id == 23 or $id == 116 or $id == 145) {
            if ($player->getGamemode() != 0) {
                $event->setCancelled();
            }
        }
        $blockX = $block->getX();

        $blockY = $block->getY();

        $blockZ = $block->getZ();

        $mainInstance = $this->fitoApi;

        $playerGroup = $mainInstance->groups->getUserDataMgr()->getGroup($player)->getName();

        if ($blockX == 868 and $blockY == 67 and $blockZ == -26) {
            if ($mainInstance->caseData->exists($playerName)) return $player->sendMessage("§7► §fВы уже получили привилегию в этом §6вайпе");

            $mainInstance->caseData->set($playerName);

            $mainInstance->caseData->save();

            $random = mt_rand(0, 2);

            if ($random == 0) {
                if ($playerGroup == "Player") {
                    Server::getInstance()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $playerName . " Vip");

                    $player->sendMessage("§7► §fТебе выпала привилегия §6Vip");
                } else {
                    $player->sendMessage(
                        "§7► §fТы уже имеешь привилегию равную или выше, поэтому привилегия не была выдана. Попытай свою удачу после вайпа!"
                    );
                }
            }

            if ($random == 1) {
                if ($playerGroup == "Player" or $playerGroup == "Vip") {
                    Server::getInstance()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $playerName . " Premium");

                    $player->sendMessage("§7► §fТебе выпала привилегия §6Premium");
                } else {
                    $player->sendMessage(
                        "§7► §fТы уже имеешь привилегию равную или выше, поэтому привилегия не была выдана. Попытай свою удачу после вайпа!"
                    );
                }
            }

            if ($random == 2) {
                if ($playerGroup == "Player" or $playerGroup == "Vip" or $playerGroup == "Premium") {
                    Server::getInstance()->dispatchCommand(new ConsoleCommandSender(), "setgroup " . $playerName . " Vip");

                    $player->sendMessage("§7► §fТебе выпала привилегия §6vip");
                } else {
                    $player->sendMessage(
                        "§7► §fТы уже имеешь привилегию равную или выше, поэтому привилегия не была выдана. Попытай свою удачу после вайпа!"
                    );
                }
            }
        }
    }

    public function onJump(PlayerJumpEvent $event) {
        $player = $event->getPlayer();
        $senderName = $player->getName();

        if (!empty($this->fitoApi->sitPlayers)) {
            if (!isset($this->fitoApi->sitPlayers[$senderName])) return;
            $targetName = $this->fitoApi->getTargetName($senderName);
            $this->fitoApi->standUp($player, $targetName);
        }
    }

    public function deleteFromCooldowns(string $player, string $command) {
        unset($this->cooldowns[$player][$command]);
    }

    public function onCommandPreprocess(PlayerCommandPreprocessEvent $event) {
        if ($event->isCancelled()) {
            return;
        }

        $player = $event->getPlayer();

        $command = strtolower($event->getMessage());
        $cooldownTime = 3;

        if (strpos($command, '/') === 0) {
            if (PvPManager::inPvP($player)) {
                $player->sendMessage('§8[§6PvP-режим§8] §eТы не можешь использовать команды во время PvP!');
                $event->setCancelled();
                return;
            }

            $command = substr($command, 1);
            $commandName = explode(' ', $command)[0];

            if ($player->getLevel()->getFolderName() == 'pvparena') {
                if ($commandName !== 'spawn') {
                    $player->sendMessage('§7► §cНа §6арене §cты можешь использовать только команду §7/§6spawn§c!');
                    $event->setCancelled(true);
                    return;
                }
            }

            if (isset($this->cooldowns[$player->getName()][$commandName]) && time() - $this->cooldowns[$player->getName()][$commandName] < $cooldownTime) {
                $player->sendMessage(
                    "§8[§aЧат§8] §eПодождите §a2 §eсек, прежде чем использовать эту команду снова"
                );
                $event->setCancelled();
            } else if (in_array($commandName, Helper::COMMANDS)) {
                if (!in_array(strtolower($player->getName()), Helper::ADMINS)) {
                    $player->sendMessage('§7► §cУ тебя нет прав на использование данной команды');
                    $event->setCancelled();
                    return;
                }

            } else {
                $this->cooldowns[$player->getName()][$commandName] = time();
                $this->fitoApi->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this, 'deleteFromCooldowns'], [$player->getName(), $commandName]), 2 * 20);

                foreach (Main::getInstance()->snoopers as $snooper) {
                    if ($commandName !== 'rca' and $commandName !== 'givemoney' and $commandName !== 'giveamethysts' and $commandName !== 'slapper' and $commandName !== 'tell' and $commandName !== 'parol' and $commandName !== 'chp' and $commandName !== 'changepassword' and $commandName !== 'password') {
                        $snooper->sendMessage("§7Игрок §a{$player->getName()} §7ввел команду §6{$command}");
                    }
                }
            }
        }
    }

    function onFood(PlayerItemConsumeEvent $event) {
        $player = $event->getPlayer();
        $id = $event->getItem()->getId();
        if ($id === 373 and $player->isCreative()) $event->setCancelled(true);
    }

    function onArrow(ProjectileLaunchEvent $event) {
        $entity = $event->getEntity();
        if ($entity instanceof \pocketmine\entity\Arrow) {
            $player = $entity->getOwningEntity();
            if ($player->isCreative()) {
                $event->setCancelled();
                $player->sendTitle('', '§cЗАПРЕЩЕНО!');
                return true;
            }
            if ($entity->getPotionId() === 24 or $entity->getPotionId() === 25) {
                $event->setCancelled();
                $player->sendTitle('', '§cЗАПРЕЩЕНО!');
                return true;
            }
        }
    }

    public function PlayerInteracttt(PlayerInteractEvent $e) {
        $p = $e->getPlayer();

        $block = $e->getBlock()->getId();

        $block_1 = $e->getBlock();

        if ($block == 145) {
            $item = $p->getInventory()->getItemInHand();

            $e->setCancelled();

            if (EconomyAPI::myMoney($p) < 300) return $p->sendMessage("§7► §fНедостаточно §eмонет§7, §fнужно §6300");

            if ($item->getDamage() < 1) return $p->sendMessage("§7► §fДанный предмет не нуждается в §eремонте");

            $item->setDamage(0);

            $p->getInventory()->setItemInHand($item);

            $p->sendMessage("§7► §fПредмет §eотремонтирован");

            EconomyAPI::reduceMoney($p, 300);
        }

        if ($block == 116) {
            $e->setCancelled();

            if (EconomyAPI::myMoney($p) < 300) return $p->sendMessage("§7► §fНедостаточно §eмонет§7, §fнужно §6300");

            EconomyAPI::reduceMoney($p, 300);

            $item = $e->getItem();

            if ($item instanceof Armor) {
                $p->sendMessage("§7► §fПредмет §eзачарован");

                $rand = mt_rand(1, 2);

                if ($rand == 1) {
                    $item->addEnchantment(Enchantment::getEnchantment(0)->setLevel(mt_rand(1, 4)));

                    $p->getInventory()->setItemInHand($item);
                }

                if ($rand == 2) {
                    $item->addEnchantment(Enchantment::getEnchantment(17)->setLevel(mt_rand(1, 3)));

                    $p->getInventory()->setItemInHand($item);
                }
            }

            if ($item->isSword()) {
                $p->sendMessage("§7► §fПредмет §eзачарован");

                $rand = mt_rand(1, 2);

                if ($rand == 1) {
                    $item->addEnchantment(Enchantment::getEnchantment(9)->setLevel(mt_rand(1, 4)));

                    $p->getInventory()->setItemInHand($item);
                }

                if ($rand == 2) {
                    $item->addEnchantment(Enchantment::getEnchantment(13)->setLevel(mt_rand(1, 2)));

                    $p->getInventory()->setItemInHand($item);
                }
            }

            if ($item->isAxe()) {
                $p->sendMessage("§7► §fПредмет §eзачарован");

                $rand = mt_rand(1, 2);

                if ($rand == 1) {
                    $item->addEnchantment(Enchantment::getEnchantment(17)->setLevel(mt_rand(1, 3)));

                    $p->getInventory()->setItemInHand($item);
                }

                if ($rand == 2) {
                    $item->addEnchantment(Enchantment::getEnchantment(15)->setLevel(mt_rand(1, 5)));
                    $p->getInventory()->setItemInHand($item);
                }
            }

            if ($item->isHoe()) {
                $p->sendMessage("§7► §fПредмет §eзачарован");

                $item->addEnchantment(Enchantment::getEnchantment(17)->setLevel(mt_rand(1, 3)));

                $p->getInventory()->setItemInHand($item);
            }

            if ($item->isShovel()) {
                $p->sendMessage("§7► §fПредмет §eзачарован");

                $item->addEnchantment(Enchantment::getEnchantment(17)->setLevel(mt_rand(1, 3)));

                $p->getInventory()->setItemInHand($item);
            }

            if ($item->isPickaxe()) {
                $p->sendMessage("§7► §fПредмет §eзачарован");

                $rand = mt_rand(1, 2);

                if ($rand == 1) {
                    $item->addEnchantment(Enchantment::getEnchantment(17)->setLevel(mt_rand(1, 3)));

                    $p->getInventory()->setItemInHand($item);
                }

                if ($rand == 2) {
                    $item->addEnchantment(Enchantment::getEnchantment(15)->setLevel(mt_rand(1, 5)));

                    $p->getInventory()->setItemInHand($item);
                }
            }

            if ($item instanceof Bow) {
                $p->sendMessage("§7► §fПредмет §eзачарован");

                $item->addEnchantment(Enchantment::getEnchantment(19)->setLevel(mt_rand(1, 4)));

                $p->getInventory()->setItemInHand($item);
            }
        }
    }

    public function onQuit(PlayerQuitEvent $event) {
        $this->fitoApi->stopTimer($event->getPlayer());
    }

    public function onKick(PlayerKickEvent $event) {
        $this->fitoApi->stopTimer($event->getPlayer());
    }

    public function onJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $playerName = strtolower($player->getName());

        if ($this->fitoApi->Config->exists($playerName)) {
            if ($this->fitoApi->Config->get($playerName) != $player->getDeviceModel()) {
                $player->kick("§fНа данном §eаккаунте §fвключена защита по §6устройству");
            }
        }

        if(!Main::$money->exists($playerName)) {
            $level = $this->fitoApi->getServer()->getDefaultLevel();
            $x = $this->fitoApi->getServer()->getDefaultLevel()->getSafeSpawn()->getX();
            $y = $this->fitoApi->getServer()->getDefaultLevel()->getSafeSpawn()->getY();
            $z = $this->fitoApi->getServer()->getDefaultLevel()->getSafeSpawn()->getZ();
            $player->teleport(new Position($x + 0.5, $y, $z + 0.5, $level));

            Main::$money->set($playerName, 0);
            Main::$money->save();
        }

        if(!Main::$amethysts->exists($playerName)) {
            Main::$amethysts->set($playerName, 0);
            Main::$amethysts->save();
        }

        BossBarManager::sendBossBarToPlayer($player, '...', BossBarManager::$entityRuntimeId);
        BossBarManager::setProgressBossBar($player, BossBarManager::$entityRuntimeId, 0);

        # $this->fitoApi->music[$player->getName()] = true;
        # $this->fitoApi->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this->fitoApi, "sendSound"], [$player, "mob.blaze.death", 1.0, 1.0]), 20 * 2);

        # $this->fitoApi->sendTopKills($event->getPlayer());
        $this->fitoApi->timers[$player->getId()] = time();

        $n = $event->getPlayer()->getName();
        if ($this->fitoApi->winners !== null) {
            if (isset($this->fitoApi->winners[$n = strtolower($n)])) {
                $place = $this->fitoApi->winners[$n];
                if ($place === 1) {
                    $pg = Server::getInstance()->getPluginManager()->getPlugin("MegaChest");
                    if ($pg !== null) {
                        $pg->getEconomyManager()->addKeys($event->getPlayer(), "DonateCase", 3);
                    }
                    $event->getPlayer()->sendMessage(
                        "§7► §eТы получил §a3 ключa к Донат-кейсу §eза §6ПЕРВОЕ место §aпо сделанным киллам §eв этом месяце!"
                    );
                } elseif ($place === 2) {
                    $pg = Server::getInstance()->getPluginManager()->getPlugin("MegaChest");
                    if ($pg !== null) {
                        $pg->getEconomyManager()->addKeys($event->getPlayer(), "DonateCase", 1);
                    }
                    $event->getPlayer()->sendMessage(
                        "§7► §eТы получил §a1 ключ к Донат-кейсу §eза §6ВТОРОЕ §eместо §aпо сделанным киллам §eв этом месяце!"
                    );
                } elseif ($place === 3) {
                    EconomyAPI::addMoney($event->getPlayer(), 20000, null, null, "Занял 3 место по топ-убийствам");
                    $event->getPlayer()->sendMessage(
                        "§7► §eТы получил §a20,000§6$ ключ к Донат-кейсу §eза §6ВТОРОЕ §eместо §aпо сделанным киллам §eв этом месяце!"
                    );
                } else {
                    return;
                }

                unset($this->fitoApi->winners[$n]);
                $this->fitoApi->killInfo->set("winners", $this->fitoApi->winners);
                $this->fitoApi->killInfo->save();
            }
        }

        if ($this->fitoApi->winners2 !== null) {
            $next = $this->fitoApi->killInfo->get("u", 0);
            if ($next - time() >= 60 * 60 * 24 * (14 - 3)) {
                $res = "";
                foreach ($this->fitoApi->winners2 as $name => $place) {
                    if ($place === 1) {
                        $res .= "§7* §eИгрок §a$name §eполучил §a2 Донат-кейса§e!\n";
                    } elseif ($place === 2) {
                        $res .= "§7* §eИгрок §a$name §eполучил §a1 Донат-кейс§e!\n";
                    }
                }

                $auth = Server::getInstance()->getPluginManager()->getPlugin('Auth');
                if ($res !== "" && $auth->isLogined($player->getName())) {
                    $res = substr($res, 0, -2);
                    $player->sendMessage("\n\n§7► §eНедавно счётчик убийств §6обновился§e!");
                    $player->sendMessage($res);
                    $player->sendMessage(
                        "§7► §eМесто §6№1 §eи §6№2 §eв топе убийств получают донат-кейсы §6каждые 2 недели§e!\n\n"
                    );
                }
            }
        }
    }

    public function onPlayerDeath(PlayerDeathEvent $e) {
        $e->setDeathMessage(null);
        $p = $e->getEntity();
        if ($p instanceof Player) {
            $plcn = $p->getLowerCaseName();

            if (!$this->fitoApi->dea->exists($plcn)) {
                $this->fitoApi->dea->set($plcn, 1);

                $this->fitoApi->dea->save();
            } else {
                $this->fitoApi->dea->set($plcn, $this->fitoApi->dea->get($plcn) + 1);

                $this->fitoApi->dea->save();
            }
        }

        if ($p->getLastDamageCause() instanceof EntityDamageByEntityEvent) {
            $d = $p->getLastDamageCause()->getDamager();
            if ($d !== null) {
                if ($d instanceof Player) {
                    PvPManager::removeFromPvP($p);
                    $p->sendMessage("§8[§6PvP-Режим§8] §eРежим деактивирован!");

                    if (!isset($this->fitoApi->kills[$dn = strtolower($d->getName())])) $this->fitoApi->kills[$dn] = 0;
                    if ($this->fitoApi->checkKill($d, $p->getAddress())) {
                        ++$this->fitoApi->kills[$dn];
                    } else {
                        $d->sendMessage("\n§7► §cТы слишком часто убиваешь игрока §a" . $p->getName() . "§c!");
                        $d->sendMessage("§7► §eУбийство не идет в §aстатистику убийств\n");
                    }
                    $this->fitoApi->deathManager($d, $p);
                }
            }
        }

        if ($p->hasPermission('fapi.cmd.back')) {
            $this->fitoApi->death[$p->getName()] = $p->getPosition();
            $p->sendMessage(
                '§7► §eИспользуй§7: §7/§6back§e, чтобы телепортироваться на место гибели!'
            );
        }
    }

    public function PlayerInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $id = $event->getItem()->getId();
        $damage = $event->getItem()->getDamage();
        $blockId = $event->getBlock()->getId();

        if (($id == 325 && $damage == 8) or ($id == 325 && $damage == 10) or $id == 351) {
            if ($player->getGamemode() == Player::CREATIVE && !$player->isOp()) {
                $event->setCancelled(true);
                $player->sendMessage("§7► §cЭтот предмет можно использовать только в §6Выживании");
                $player->getInventory()->setItemInHand(new Item(Item::AIR, 0, 1));
                return;
            }
        }

        if (($blockId == 218 or $blockId == 54) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($id == 103 or $blockId == 103) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 86 or $id == 86) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 361 or $id == 361) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 362 or $id == 362) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 133 or $id == 133) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 218 or $id == 218) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 391 or $id == 391) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 392 or $id == 392) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 295 or $id == 295) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 458 or $id == 458) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 61 or $id == 61) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 58 or $id == 58) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 41 or $id == 41) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 57 or $id == 57) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 42 or $id == 42) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 410 or $id == 410) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 54 or $id == 54) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 130 or $id == 130) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 63 or $id == 63) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 30 or $id == 30) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 131 or $id == 131) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 49 or $id == 49) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 33 or $id == 33) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 29 or $id == 29) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 14 or $id == 14) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        if (($blockId == 129 or $id == 129) and $player->getGamemode() != 0) {
            $event->setCancelled(true);
            return;
        }

        $lagBloks = array(
            247, 251, 426, 242, 246, 230, 209, 210, 211, 212, 188, 189, 90, 27, 28, 119, 137, 358, 395, 331, 88, 152, 51, 52, 66,
            93, 94, 122, 126, 407, 443, 408, 342, 321, 380, 34, 23, 55, 75, 199, 123, 124, 125, 127, 111, 149, 150, 115,
            356, 404, 420, 385, 26, 10, 11, 8, 81, 62, 83, 68, 7, 379, 380, 19, 19, 200, 250, 255, 248, 249, 247, 247, 240, 120,
            117, 118, 83, 339, 138, 116, 145, 389, 170, 57, 9, 259, 218, 46, 76, 397, 41, 77, 143, 175
        );
        if (!empty($id) and in_array($id, $lagBloks)) {
            $player->sendMessage("");
            $player->getInventory()->setItemInHand(new Item(Item::AIR, 0, 1));
            $event->setCancelled(true);
            return;
        }
        if (!empty($blockId) and in_array($blockId, $lagBloks)) {
            $event->setCancelled(true);
            return;
        }

        if ($id == 328 or $id == 383 or $id == 333 or $id == 407) {
            $event->setCancelled(true);
            $player->sendPopup("§cВременно не работает");
            $player->getInventory()->setItemInHand(new Item(Item::AIR, 0, 1));
            return;
        }
    }

    public function InventoryPickup(InventoryPickupItemEvent $ev) {
        $p = $ev->getInventory()->getHolder();
        if ($p instanceof Player and ($p->getAllowFlight() or $p->isCreative())) $ev->setCancelled(true);
    }

    public function useFireworks(PlayerInteractEvent $event) {
        $player = $event->getPlayer();

        if ($event->getItem()->getId() == 381 && $player->getInventory()->getChestplate()->getId() === 444) {
            $player->getInventory()->removeItem(Item::get(381, 0, 1));
            $player->setMotion($player->getDirectionVector()->add(0, 1)->multiply(1));
        }
    }

    public function onBreak(BlockBreakEvent $event) {
        $player = $event->getPlayer();
        $block = $event->getBlock();

        if ($player->getLevel()->getFolderName() !== 'world') {
            if (MineGenerator::isBlockInMine($block->getX(), $block->getY(), $block->getZ()) and $player->getLevel()->getFolderName() == 'spawn') {
                return;
            }

            if (!in_array(strtolower($player->getName()), Helper::ADMINS)) {
                $event->setCancelled();
                return;
            }
        }

        $id = $event->getBlock()->getId();
        if ($event->isCancelled()) return;
        if ($id === 7 and !$player->isOp()) {
            $event->setCancelled();
            return true;
        }
    }

    public function onPlace(BlockPlaceEvent $event) {
        $player = $event->getPlayer();

        if ($player->getLevel()->getFolderName() !== 'world') {
            if (!in_array(strtolower($player->getName()), Helper::ADMINS)) {
                $event->setCancelled();
                return;
            }
        }
    }

    public function noDrop(ItemFrameDropItemEvent $e) {
        $e->setCancelled();
    }

    public function onExplode(EntityExplodeEvent $e) {
        $e->setCancelled();
    }

    public function handlePlayerChat1(PlayerChatEvent $event){
        $player = $event->getPlayer();

        if(!$player->isOp()){
            return;
        }

        if($event->getMessage() !== '.arena'){
            return;
        }

        $event->setCancelled(true);

        $nbt = new CompoundTag("", [
    		"Pos" => new ListTag("Pos", [
        		new DoubleTag("", $player->x),
        		new DoubleTag("", $player->y),
        		new DoubleTag("", $player->z)
    		]),
    		"Motion" => new ListTag("Motion", [
        		new DoubleTag("", 0),
        		new DoubleTag("", 0),
        		new DoubleTag("", 0)
    		]),
    		"Rotation" => new ListTag("Rotation", [
        		new DoubleTag("", $player->yaw),
        		new DoubleTag("", $player->pitch)
    		]),
    		"Skin" => new CompoundTag("Skin", [
        		"Data" => new StringTag("Data", $player->getSkinData()),
        		"Name" => new StringTag("Name", $player->getSkinId())
    		])
		]);

        $npc = Entity::createEntity(Villager::NETWORK_ID, $player->level, $nbt);    
        $npc->setNameTag(Main::NAME_NPC_ARENA); 
        $npc->setScale(1.5);
        $npc->setNameTagVisible(true); 
        $npc->setNameTagAlwaysVisible(true);
        $npc->spawnToAll();
        $npc->saveNBT();

        $player->sendMessage('§8[§6Арена§8] §eNPC заспавнен!');
    }

    public function handlePlayerChat2(PlayerChatEvent $event){
        $player = $event->getPlayer();

        if(!$player->isOp()){
            return;
        }

        if($event->getMessage() !== '.survival'){
            return;
        }

        $event->setCancelled(true);

        $nbt = new CompoundTag("", [
    		"Pos" => new ListTag("Pos", [
        		new DoubleTag("", $player->x),
        		new DoubleTag("", $player->y),
        		new DoubleTag("", $player->z)
    		]),
    		"Motion" => new ListTag("Motion", [
        		new DoubleTag("", 0),
        		new DoubleTag("", 0),
        		new DoubleTag("", 0)
    		]),
    		"Rotation" => new ListTag("Rotation", [
        		new DoubleTag("", $player->yaw),
        		new DoubleTag("", $player->pitch)
    		]),
    		"Skin" => new CompoundTag("Skin", [
        		"Data" => new StringTag("Data", $player->getSkinData()),
        		"Name" => new StringTag("Name", $player->getSkinId())
    		])
		]);

        $npc = Entity::createEntity(Villager::NETWORK_ID, $player->level, $nbt);    
        $npc->setNameTag(Main::NAME_NPC_SURVIVAL); 
        $npc->setScale(1.5);
        $npc->setNameTagVisible(true); 
        $npc->setNameTagAlwaysVisible(true);
        $npc->spawnToAll();
        $npc->saveNBT();

        $player->sendMessage('§8[§6Мир Выживания§8] §eNPC заспавнен!');
    }

    public function handlePlayerChat3(PlayerChatEvent $event){
        $player = $event->getPlayer();

        if(!$player->isOp()){
            return;
        }

        if($event->getMessage() !== '.soon'){
            return;
        }

        $event->setCancelled(true);

        $nbt = new CompoundTag("", [
    		"Pos" => new ListTag("Pos", [
        		new DoubleTag("", $player->x),
        		new DoubleTag("", $player->y),
        		new DoubleTag("", $player->z)
    		]),
    		"Motion" => new ListTag("Motion", [
        		new DoubleTag("", 0),
        		new DoubleTag("", 0),
        		new DoubleTag("", 0)
    		]),
    		"Rotation" => new ListTag("Rotation", [
        		new DoubleTag("", $player->yaw),
        		new DoubleTag("", $player->pitch)
    		]),
    		"Skin" => new CompoundTag("Skin", [
        		"Data" => new StringTag("Data", $player->getSkinData()),
        		"Name" => new StringTag("Name", $player->getSkinId())
    		])
		]);

        $npc = Entity::createEntity(Villager::NETWORK_ID, $player->level, $nbt);    
        $npc->setNameTag('§7soon..'); 
        $npc->setScale(1.2);
        $npc->setNameTagVisible(true); 
        $npc->setNameTagAlwaysVisible(true);
        $npc->spawnToAll();
        $npc->saveNBT();

        $player->sendMessage('§8[§6Soon§8] §eNPC заспавнен!');
    }

    public function onChat(PlayerChatEvent $e) {
        if ($e->isCancelled()) {
            return;
        }

        $p = $e->getPlayer();
        $nick = strtolower($p->getName());

        if (!Auth::getInstance()->isLogined($nick)) {
            return;
        }

        $data = Main::$gameTime->getAll();

        if (isset($data[$nick])) {
            if ($data[$nick] < 600) {
                $p->sendMessage("§8[§aЧат§8] §cЧтобы писать, тебе осталось наиграть еще " . Helper::convertTimeOptimized(600 - $data[$nick]));
                $e->setCancelled();
                return;
            }
        }

        if (isset($this->spam[$nick])) {
            if (time() - $this->spam[$nick] <= 2) {
                if ($this->auth->isLogined($nick)) {
                    return;
                }

                $e->setCancelled();

                $p->sendMessage("§8[§aЧат§8] §cНе спамь, подожди §a1 §eсекунду");
            }
        }

        $this->spam[$nick] = time();

        $msg = $e->getMessage();

        if (strpos($msg, 'pocketmine:') !== false) {
            $e->setCancelled(true);
        }

        $il = explode(".", $msg);

        $ip = explode(".", $msg);

        if (sizeof($ip) >= 4) {
            if (preg_match('/[0-9]+/', $ip[1])) {
                $e->setCancelled();

                $p->sendMessage("§8[§aЧат§8] §cНе нужно ничего рекламировать");
            }
        } elseif (sizeof($il) >= 4) {
            if (preg_match('/[0-9]+/', $il[1])) {
                $e->setCancelled();

                $p->sendMessage("§8[§aЧат§8] §cНе нужно ничего рекламировать");
            }
        }

        $links = [
            ".rу", ".io", ".гu", ".ГU", ".РУ", ".ру", "WEBJENKINS", "webjenkins", ".ru", ".net", ".pro", "24serv",
            ".com", ".co", ".org", ".info", ".tk", ".fun", ".cc", ". ru", ". net", ". pro", ". com", ". co", ". org", ". info",
            ". tk", ". fun", ". cc", ".RU", ".NET", ".PRO", ".COM", ".CO", ".ORG", ".INFO", ".TK", ".FUN", ".CC", ". RU", ". NET",
            ". PRO", ". COM", ". CO", ". ORG", ". INFO", ". TK", ". FUN", ". CC", ". Ru", ". NET", ". PRO", ". COM", ". Co",
            ". ORG", ". INFO", ". Tk", "mcpehost", "MCPEHOST", ". NET", ". PRO", ". COM", ". cO", ". ORG", ". INFO", ". tK", ". Me",
            ". cC", "Net", "Pro", "Com", "Org", "NEt", "PRo", "COm", "ORg", "nEt", "pRo", "cOm", "oRg", "nET", "pRO", "cOM", "oRG",
            "neT", "prO", "coM", "orG", "NeT", "PrO", "CoM", "OrG", "Info", "INfo", "INFo", "iNFO", "inFO", "infO", "InfO", "InFo",
            "iNFo", ".Su", ".su", ".sU", ".SU", ". su", ". Su", ". sU", ". SU", "19132", "ML", "Ml", "ml", "mL", "Мl", "МL",
            "мl", "мL"
        ];
        foreach ($links as $end) {
            if (strpos($msg, $end) !== false) {
                $e->setCancelled();

                $p->sendMessage("§8[§aЧат§8] §cНе нужно ничего рекламировать");
            }
        }
    }

    public function playerTag(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $msg = $event->getMessage();
        $words = explode(" ", $msg);

        foreach ($words as $word) {
            if (strpos($word, "@") === 0) {
                $name = substr($word, 1);
                $targetPlayer = Server::getInstance()->getPlayer($name);

                if ($targetPlayer instanceof Player) {
                    $formattedName = "§l§e@" . $targetPlayer->getName() . "§r§7";
                    $msg = str_replace("@" . $name, $formattedName, $msg);

                    $targetPlayer->sendPopup("§f↪ §eТебя упомянули в чате!");
                }

            } elseif (strpos($word, "!") === 0 and strpos($word, "@") === 1) {
                $name = substr($word, 2);
                $targetPlayer = Server::getInstance()->getPlayer($name);

                if ($targetPlayer instanceof Player) {
                    $formattedName = "§l§e@" . $targetPlayer->getName() . "§r§7";
                    $msg = str_replace("@" . $name, $formattedName, $msg);

                    $targetPlayer->sendPopup("§f↪ §eТебя упомянули в чате!");
                }
            }
        }

        $event->setMessage($msg);
    }
}