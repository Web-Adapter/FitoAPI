<?php

namespace FitoApi;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\CallbackTask;

use pocketmine\command\ {
    Command, CommandSender
};

use pocketmine\event\Listener;
use pocketmine\event\block\ {
    ItemFrameDropItemEvent, BlockBreakEvent
};
use pocketmine\event\entity\ {
    EntityExplodeEvent, EntityDamageEvent, EntityDamageByEntityEvent
};
use pocketmine\event\player\ {
    PlayerDeathEvent, PlayerRespawnEvent, PlayerInteractEvent, PlayerJoinEvent, PlayerEvent
};

use pocketmine\block\Block;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\network\mcpe\protocol\StopSoundPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\math\Vector3;
use pocketmine\item\Item;
use pocketmine\item\Armor;
use pocketmine\item\ItemBlock;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\entity\Entity;
use pocketmine\level\Position;
use pocketmine\level\Level;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\tile\EnderChest;
use pocketmine\tile\Tile;
use pocketmine\inventory\EnderChestInventory;
use pocketmine\entity\Effect;
use pocketmine\entity\ {
    Wither2, FallingSand, Vindicator, Villager, Human, Zombie, Evoker, Wither
};
use tempist\bosses\entity\ {
    WitherSkull2, WitherSkeleton2, WitherGuardian, BigSkeleton, BigSpider, Silverfish2
};
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\SetEntityLinkPacket;
use pocketmine\network\mcpe\protocol\AddEntityPacket;

use slapper\entities\ {
    SlapperHuman, SlapperVillager, SlapperEvoker, SlapperWitherSkeleton
};
use pocketmine\utils\Config;
use pocketmine\level\sound\DoorCrashSound;
use pocketmine\scheduler\Task;
use Auth\Main as Auth;

use FitoApi\manager\BossBarManager;
use FitoApi\manager\EconomyManager as EconomyAPI;
use FitoApi\manager\AmethystsManager;

use FitoApi\entity\SittingEntity;

use FitoApi\task\UpdatePvPTask;
use FitoApi\task\RestartTask;
use FitoApi\task\SittingTask;
use FitoApi\task\ArmorColorsTask;
use FitoApi\task\UpdateBossBarTextTask;

use FitoApi\command\amethysts\GiveAmethystsCommand;
use FitoApi\command\amethysts\AmethystsCommand;

use FitoApi\command\money\MoneyCommand;
use FitoApi\command\money\SeeMoneyCommand;
use FitoApi\command\money\GiveMoneyCommand;
use FitoApi\command\money\PayCommand;

use FitoApi\command\other\RestartCommand;
use FitoApi\command\other\ConsoleCommand;
use FitoApi\command\other\ApcCommand;
use FitoApi\command\other\TitleCommand;
use FitoApi\command\other\FreeflyCommand;
use FitoApi\command\other\FreegmCommand;
use FitoApi\command\other\FreepionerCommand;
use FitoApi\command\other\FreeguardCommand;
use FitoApi\command\other\FreegladiatorCommand;
use FitoApi\command\other\FlylistCommand;
use FitoApi\command\other\DonatelistCommand;
use FitoApi\command\other\LogCommand;
use FitoApi\command\other\RepairAllCommand;
use FitoApi\command\other\EnchantAllCommand;
use FitoApi\command\other\WhoisCommand;
use FitoApi\command\other\CapeCommand;
use FitoApi\command\other\JmCommand;
use FitoApi\command\other\FreezeCommand;
use FitoApi\command\other\UnFreezeCommand;
use FitoApi\command\other\GriefCommand;
use FitoApi\command\other\CopyCommand;
use FitoApi\command\other\RainBowCommand;
use FitoApi\command\other\ReviseCommand;
use FitoApi\command\other\UnReviseCommand;
use FitoApi\command\other\DeviceCommand;
use FitoApi\utils\Helper;

class Main extends PluginBase implements Listener {
    const NAME_NPC_ARENA = "        §l§7▼ §6АРЕНА §7▼§r\n" .
                 "§fНажми, чтобы телепортироваться!";

    const NAME_NPC_SURVIVAL = "    §l§7▼ §aМИР ВЫЖИВАНИЯ §7▼§r\n" .
                 "§fНажми, чтобы телепортироваться!";

    public static $money, $amethysts, $bonus, $bogenchant, $vendetta, $killsLimit, $fuck, $god, $size, $vanish = [], $spec, $gameTime;
    public $death, $maxhp = [], $dupe, $killInfo, $winners = null, $winners2 = null, $timers, $copy = [], $grief = [], $freefly = [], $freeze, $revise, $freezeUse, $apc = [], $armors = [], $pendingSits = [], $music = [], $sitPlayers = [], $snoopers = [], $cfgSwords;
    private $commandHandler;
    public static $timeToRestart = 60 * 60 + 1;

    private static $instance;
    
    public static function getInstance() {
        return self::$instance;
    }

    public function onEnable() {
        self::$instance = $this;
        
        self::$amethysts = new Config($this->getDataFolder() . "resourses/amethysts.yml", Config::YAML);
        self::$money = new Config($this->getDataFolder() . "resourses/money.yml", Config::YAML);
        self::$gameTime = new Config($this->getDataFolder() . "resourses/gameTime.yml", Config::YAML);

        $this->perms = $this->getServer()->getPluginManager()->getPlugin("PurePerms");

        $this->dropEvent = $this->getServer()->getPluginManager()->getPlugin("DropEvent");
        $this->bossEvent = $this->getServer()->getPluginManager()->getPlugin("Bosses");
        $this->airDrop = $this->getServer()->getPluginManager()->getPlugin("AirDrop");
        $this->goldRush = $this->getServer()->getPluginManager()->getPlugin("Buyer");
        $this->mevent = $this->getServer()->getPluginManager()->getPlugin("MysticalEvent");
        $this->lvlSystem = $this->getServer()->getPluginManager()->getPlugin("LvlSystem");
        $this->clanSystem = $this->getServer()->getPluginManager()->getPlugin("ClanSystem");
        $this->ranks = $this->getServer()->getPluginManager()->getPlugin("Ranks");

        $this->data = new Config($this->getDataFolder()."resourses/data.yml", Config::YAML);
        $this->sozd = (new Config($this->getDataFolder()."resourses/sozd.json", Config::JSON))->getAll();
        $this->freeData = (new Config($this->getDataFolder()."resourses/free_data.json", Config::JSON))->getAll();
        $this->caseData = new Config($this->getDataFolder()."resourses/case_data.yml", Config::YAML);
        $this->clans = $this->getServer()->getPluginManager()->getPlugin("ClanSystem");
        $this->groups = $this->getServer()->getPluginManager()->getPlugin("PurePerms");
        $this->economy = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");

        $this->infoAboutCommands = new Config($this->getDataFolder() . "resourses/infoAboutCommands.json", Config::JSON);
        $this->killInfo = $info = new Config($this->getDataFolder() . "resourses/killInfo.json", Config::JSON);
        $this->timer = (new Config($this->getDataFolder() . "resourses/timer.json", Config::JSON))->getAll();
        $this->kills = $k = ($kk = new Config($this->getDataFolder() . "resourses/kills.json", Config::JSON))->getAll();
        $this->drops = (new Config($this->getDataFolder() . 'resourses/drops.json', Config::JSON))->getAll();
        $this->killss = new Config($this->getDataFolder() . "resourses/kills.json", Config::JSON);

        $this->dea = new Config($this->getDataFolder() . "resourses/deaths.json", Config::JSON);

        $this->Config = new Config($this->getDataFolder()."resourses/devices.json", Config::JSON);

        $this->getServer()->getCommandMap()->unregister($this->getServer()->getCommandMap()->getCommand("restart"));
        $this->getServer()->getCommandMap()->register('restart', new RestartCommand($this));

        $this->getServer()->getCommandMap()->register('cosnole', new ConsoleCommand($this));
        $this->getServer()->getCommandMap()->register('device', new DeviceCommand($this));
        $this->getServer()->getCommandMap()->register('pay', new PayCommand($this));
        $this->getServer()->getCommandMap()->register('money', new MoneyCommand($this));
        $this->getServer()->getCommandMap()->register('seemoney', new SeeMoneyCommand($this));
        $this->getServer()->getCommandMap()->register('givemoney', new GiveMoneyCommand($this));
        $this->getServer()->getCommandMap()->register('amethysts', new AmethystsCommand($this));
        $this->getServer()->getCommandMap()->register('giveamethysts', new GiveAmethystsCommand($this));
        $this->getServer()->getCommandMap()->register("apc", new ApcCommand); 
        $this->getServer()->getCommandMap()->register("title", new TitleCommand);  
        $this->getServer()->getCommandMap()->register("freefly", new FreeflyCommand);
        $this->getServer()->getCommandMap()->register("freegm", new FreegmCommand);
        $this->getServer()->getCommandMap()->register("freepioner", new FreepionerCommand);
        $this->getServer()->getCommandMap()->register("freeguard", new FreeguardCommand);
        $this->getServer()->getCommandMap()->register("freegladiator", new FreegladiatorCommand);
        $this->getServer()->getCommandMap()->register("flylist", new FlylistCommand);
        $this->getServer()->getCommandMap()->register("donatelist", new DonatelistCommand);
        $this->getServer()->getCommandMap()->register("log", new LogCommand);
        $this->getServer()->getCommandMap()->register("whois", new WhoisCommand);
        $this->getServer()->getCommandMap()->register("repairall", new RepairAllCommand);
        $this->getServer()->getCommandMap()->register("enchantall", new EnchantAllCommand);
        $this->getServer()->getCommandMap()->register("cape", new CapeCommand);
        $this->getServer()->getCommandMap()->register("jm", new JmCommand);
        $this->getServer()->getCommandMap()->register("freeze", new FreezeCommand);
        $this->getServer()->getCommandMap()->register("unfreeze", new UnFreezeCommand);
        # $this->getServer()->getCommandMap()->register("rainbow", new RainBowCommand);
        $this->getServer()->getCommandMap()->register("grief", new GriefCommand);
        # $this->getServer()->getCommandMap()->register("copy", new CopyCommand);
        $this->getServer()->getCommandMap()->register("revise", new ReviseCommand);
        $this->getServer()->getCommandMap()->register("unrevise", new UnReviseCommand);

        $this->getServer()->getPluginManager()->registerEvents(new EventHandler($this), $this);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, "broadcaster"]), 20 * 170);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, 'checkExpiredSits']), 20);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, 'updateTask']), 20);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, "clearEntities"], [false]), 20 * 60 * 5);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, "setMaxHp"], []), 20);
        # $this->getServer()->getScheduler()->scheduleRepeatingTask(new CallbackTask([$this, "sendSoundToPlayers"], ["mob.blaze.death"]), 20 * 60 * 4 + 15 * 20);

        $this->getServer()->getScheduler()->scheduleRepeatingTask(new ArmorColorsTask($this), 20);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new RestartTask($this), 20);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new UpdateBossBarTextTask($this), 20);
        $this->getServer()->getScheduler()->scheduleRepeatingTask(new UpdatePvPTask($this), 20);
        BossBarManager::$entityRuntimeId = Entity::$entityCount++;

        $this->removeCreativeItem();
        $this->getKillInfo($info, $k, $kk);
        $this->getServer()->loadLevel('world');
        $this->getServer()->loadLevel('pvparena');
    }

    public function deleteChest(Player $player){
        $name = $player->getName();

        if(isset($this->chests[$name])){
            $pos = $this->chests[$name]["pos"];
            $replace = $this->chests[$name]["block"];
            $block = Block::get(...explode(":", $replace));
            $tile = $pos->getLevel()->getTile($pos);

            if($tile instanceof EnderChest){
                $tile->close();
                $pos->level->sendBlocks([$player], [$block]);
            }

            unset($this->chests[$name]);
        }
    }

    public function placeChest(Player $player) : bool {
        $pos = new Position(floor($player->x), floor($player->y) - 4, floor($player->z), $player->level);
        $replace = $pos->level->getBlock($pos);
        $id = $replace->getId() . ":" . $replace->getDamage();
        $nbt = $this->getChestNBT($pos);
        $tile = Tile::createTile(Tile::ENDER_CHEST, $player->level, $nbt);
        $block = Block::get(Block::ENDER_CHEST, 0, $pos);
        $block->level->sendBlocks([$player], [$block]);

        if($player->getLevel()->getTile($pos) instanceof EnderChest){
            $this->chests[$player->getName()] = ["pos" => $pos, "block" => $id];
            $ec = $player->getEnderChestInventory();
            $ec->openAt($pos);
            return true;
        }

        return false;
    }

    public function getChestNBT(Position $pos) : CompoundTag {
        return new CompoundTag("", [
            new StringTag("id", Tile::ENDER_CHEST),
            new IntTag("x", (int) $pos->x),
            new IntTag("y", (int) $pos->y),
            new IntTag("z", (int) $pos->z)
        ]);
    }

    public function onCommand(CommandSender $p, Command $command, $label, array $args) {
        $level = $this->getServer()->getDefaultLevel();
        $x = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getX();
        $y = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getY();
        $z = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getZ();

        if (!$p instanceof Player) return $p->sendMessage("§7► §cКоманда предназначена исключительно для игроков");

        if ($this->getCommandsInfo($p, $command->getName())) return;

        $sender = $p;

        if ($command->getName() == "ec"){
            if ($sender->getGamemode() != 0) {
                $sender->sendMessage("§7► §cТы должен быть в Выживании!");
                return false;
            }

            if (!$this->placeChest($sender)){
                $sender->sendMessage("§7► §cНе удалось открыть виртуальный сундук! Выйди на просторную местность!");
                return true;
            }
        }

        if ($command->getName() === "sit") {
            if (count($args) == 0) return $sender->sendMessage("§7► §eИспользование§7: §7/§6sit (никнейм)");
            if ($this->getServer()->getPlayer($targetName = $args[0])) {
                if (strtolower($sender->getName()) == strtolower($targetName)) return $sender->sendMessage("§7► §cСамому на себя не сесть!");
                if (!$sender->isCreative()) return $sender->sendMessage("§7► §cТолько в Креативе!");

                $targetPlayer = $this->getServer()->getPlayer($targetName);

                if (!$targetPlayer->isCreative()) return $sender->sendMessage("§7► §cИгрок должен быть в Креативе!");

                if ($sender->isOp()) {
                    $this->toggleSit($sender, $targetPlayer);
                    return true;
                }

                if ($targetPlayer instanceof Player) {
                    $senderName = $sender->getName();
                    $targetName = $targetPlayer->getName();
                    if (isset($this->pendingSits[$targetName][$senderName])) {
                        $this->toggleSit($sender, $targetPlayer);
                        unset($this->pendingSits[$targetName][$senderName]);
                        return true;
                    } else {
                        $this->pendingSits[$senderName][$targetName] = time() + 20;
                        $sender->sendMessage("§7► §eЗапрос на сидение §aотправлен");
                        $this->getServer()->getPlayer($targetName)->sendMessage(
                            "§7► §a" . $sender->getName() . " §eхочет сесть на тебя. Подтверди командой §7/§6sit accept§e в течение §a20 §eсекунд"
                        );
                        return true;
                    }

                } else {
                    $sender->sendMessage("§7► §cИгрок не найден или не в сети!");
                }

            } elseif (strtolower($args[0]) === "accept") {
                $senderName = $sender->getName();
                foreach ($this->pendingSits as $targetName => $requests) {
                    if (isset($requests[$senderName]) && $requests[$senderName] >= time()) {
                        $targetPlayer = $this->getServer()->getPlayer($targetName);
                        if ($targetPlayer instanceof Player) {
                            $this->toggleSit($targetPlayer, $sender);
                            unset($this->pendingSits[$targetName][$senderName]);
                            return true;
                        }
                    }
                }

                $sender->sendMessage("§7► §cНет ожидающих запросов на сидение на тебе");
                return true;
            }
        }

        if ($command->getName() == "near") {
            foreach ($this->getServer()->getOnlinePlayers() as $players) {
                if ($p->distance($players) <= 90) {
                    if ($p != $players) {
                        $p->sendMessage(
                            "§7► §eБлижайший к тебе игрок §7— §a" . $players->getName() . "§e, расстояние §6" . floor($p->distance($players)) . " §eблоков"
                        );
                    } else {
                        $p->sendMessage("§7► §cПоблизости §6игроков §cне найдено");
                    }
                }
            }
        }

        if ($command->getName() == "deleff") {
            $p->removeAllEffects();

            $p->sendMessage("§7► §eТы очистил все наложенные на тебя §6эффекты");
        }

        if ($command->getName() == "nv") {
            if (count($args) == 0) return $p->sendMessage("§7► §eИспользование§7: §7/§6nv on§7/§6off");

            if ($args[0] == "on") {
                $p->addEffect(Effect::getEffect(16)->setAmplifier(0)->setDuration(20 * 99999));

                $p->sendMessage("§7► §eТы §aвключил §eночное зрение");
            }

            if ($args[0] == "off") {
                $p->removeEffect(16);

                $p->sendMessage("§7► §eТы §cотключил §eночное зрение");
            }
        }

        /* if ($command->getName() == "music") {
            if (count($args) == 0) return $p->sendMessage("§7► §eИспользование§7: §7/§6music on§7/§6off");

            if ($args[0] == "on") {
                if (!in_array($p->getName(), $this->music)) {
                    $this->music[$p->getName()] = true;

                    $p->sendMessage("§7► §eТы §aвключил §5музыку");
                    $this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask([$this, "sendSound"], [$p, "mob.blaze.death", 1.0, 1.0]), 20);
                } else {
                    $p->sendMessage("§7► §eУ вас §5музыка §eуже включена");
                }
            }

            if ($args[0] == "off") {
                if (in_array($p->getName(), $this->music)) {
                    unset($this->music[$p->getName()]);

                    $stopSoundPacket = new StopSoundPacket();
                    $stopSoundPacket->soundName = '';
                    $stopSoundPacket->stopAll = true;
                    $p->dataPacket($stopSoundPacket);

                    $p->sendMessage("§7► §eТы §cвыключил §5музыку");
                } else {
                    $p->sendMessage("§7► §eУ тебя §5музыка §eне включена");
                }
            }
        } */

        switch ($command->getName()) {
            case "stats";
                $sender->sendMessage(
                    "§7► §eТвоя §eстатистика§7:\n§7* §fУбийства§7: §6" . $this->killss->get($sender->getLowerCaseName()) . "\n§7* §fСмертей§7: §c" . $this->dea->get($sender->getLowerCaseName()) . "\n§7* §fДенежные средства§7: §e" . EconomyAPI::myMoney($sender) . '§6$' . "\n§7* §fПривилегия§7: §" . mt_rand(1, 6) . "" . $this->perms->getUserDataMgr()->getGroup($sender)->getName()
                );
                break;

            case "maxhp";
                if (!isset($this->maxhp[$sender->getLowerCaseName()])) {
                    $this->maxhp[$sender->getLowerCaseName()] = true;
                    $sender->setMaxHealth(25);
                    $sender->setHealth(25);
                    $sender->sendMessage("§7► §eТы установил себе 25 хп");
                } else {
                    $sender->sendMessage("§7► §cДанная команда тебе будет доступна после рестарта");
                }

                break;

            case "spec";
                if (count($args) < 1 or count($args) > 1) return $sender->sendMessage(
                    "§7► §eИспользование§7: §7/§6spec §6никнейм§7/§6off\n§7► §aНе забудь сложить вещи!"
                );
                if (!isset($args[0])) return;

                if ($args[0] != "off") {
                    $pl = $this->getServer()->getPlayer($args[0]);

                    if ($pl == null) return $sender->sendMessage("§7► §cИгрок не найден или не в сети!");

                    if (!$this->isInventoryEmpty($sender)) return $sender->sendMessage("§7► §fТы забыл сложить вещи!");

                    Main::$spec[$sender->getLowerCaseName()] = true;

                    $sender->teleport($pl->getPosition());
                    $sender->getInventory()->clearAll();
                    $sender->setGamemode(3);
                    $sender->sendMessage("§7► §eСлежка за игроком §a" . $pl->getName() . "§e...");
                } else {
                    if ($sender->getGamemode() == 3) {
                        unset(Main::$spec[$sender->getLowerCaseName()]);
                        $sender->teleport($this->getServer()->getDefaultLevel()->getSafeSpawn());
                        $sender->setGamemode(0);
                        $sender->sendMessage("§7► §eТы вышел с режима слежки");
                    } else {
                        $sender->sendMessage("§7► §cТы не в режиме слежки");
                    }
                }
                break;

            case "dupe";
                if (!isset($this->dupe[$sender->getLowerCaseName()])) {
                    if ($sender->getInventory()->getItemInHand()->getId() == 0) return $sender->sendMessage("§7► §cВозьмите предмет в руку");
                    $sender->getInventory()->setItemInHand(
                        Item::get($sender->getInventory()->getItemInHand()->getId(), $sender->getInventory()->getItemInHand()->getDamage(), 64)
                    );
                    $sender->sendMessage("§7► §aУспешный дюп");
                    $this->dupe[$sender->getLowerCaseName()] = true;
                } else {
                    $sender->sendMessage("§7► §cДанная команда тебе будет доступна после рестарта");
                }
                break;

            case "speed";
                if ($sender->getGamemode() != 1) return $sender->sendMessage("§7► §cИспользуй в Креативе");
                if (count($args) == 0) {
                    $sender->sendMessage("§7► §eИспользование§7: §7/§6speed 1 §7/§6off");
                    return true;
                }

                if ($args[0] == "1") {
                    $sender->addEffect(Effect::getEffect(1)->setAmplifier(0)->setDuration(20 * 99999));

                    $sender->sendMessage("§7► §eСкорость 1 успешно §aвключена");
                }

                if ($args[0] == "off") {
                    $sender->removeEffect(1);

                    $sender->sendMessage("§7► §eСкорость успешно §cвыключена");
                }

                break;

            case 'tell':
                if (!isset($args[1])) return $sender->sendMessage('§7► §eИспользование§7: §7/§6tell (никнейм) (текст)');

                $online = $this->getServer()->getPlayer($args[0]);
                if (!$online) {
                    return $sender->sendMessage('§7► §cИгрок не найден или не в сети!');
                }

                array_shift($args);
                
                $sender->sendMessage(
                    '§7► §eТы отправил сообщение для §a' . $online->getName() . '§7: §6' . implode(' ', $args)
                );
                
                $online->sendMessage(
                    '§7► §eТы получил сообщение от §a' . $sender->getName() . '§7: §6' . implode(' ', $args)
                );

                break;

            case "bog":
                if (isset(Main::$bogenchant[strtolower($sender->getName())])) {
                    $sender->sendMessage('§7► §cДанная команда тебе будет доступна после рестарта');
                    break;
                }

                $item = $sender->getItemInHand();
                $sender->getInventory()->removeItem($item);
                if ($item->isSword()) {
                    $item->addEnchantment((Enchantment::getEnchantment(9)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(12)->setLevel(3)));
                    $item->addEnchantment((Enchantment::getEnchantment(13)->setLevel(2)));
                    $item->addEnchantment((Enchantment::getEnchantment(17)->setLevel(1)));
                    $sender->sendMessage('§7► §eТы успешно зачаровал этот предмет!');
                    Main::$bogenchant[strtolower($sender->getName())] = true;
                } elseif ($item->isArmor()) {
                    $item->addEnchantment((Enchantment::getEnchantment(0)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(1)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(2)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(3)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(4)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(5)->setLevel(4)));
                    $sender->sendMessage('§7► §eТы успешно зачаровал этот предмет!');
                    Main::$bogenchant[strtolower($sender->getName())] = true;
                } elseif ($item->getId() == 261) {
                    $item->addEnchantment((Enchantment::getEnchantment(19)->setLevel(3)));
                    $item->addEnchantment((Enchantment::getEnchantment(20)->setLevel(3)));
                    $item->addEnchantment((Enchantment::getEnchantment(21)->setLevel(3)));
                    $item->addEnchantment((Enchantment::getEnchantment(22)->setLevel(1)));
                    $sender->sendMessage('§7► §eТы успешно зачаровал этот предмет!');
                    Main::$bogenchant[strtolower($sender->getName())] = true;
                } elseif ($item->isTool()) {
                    $item->addEnchantment((Enchantment::getEnchantment(15)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(16)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(17)->setLevel(4)));
                    $item->addEnchantment((Enchantment::getEnchantment(18)->setLevel(4)));
                    $sender->sendMessage('§7► §eТы успешно зачаровал этот предмет!');
                    Main::$bogenchant[strtolower($sender->getName())] = true;
                } else {
                    $sender->sendMessage('§7► §сЭтот предмет невозможно зачаровать');
                }
                $sender->getInventory()->setItemInHand($item);
                break;

            case "repair":
                $item = $sender->getItemInHand();
                if ($item->getId() == 0) {
                    $sender->sendMessage('§7► §сВозьми в руку инструмент');
                } elseif ($item->isTool() or $item->isArmor() or $item->isSword() or $item->getId() == 261) {
                    $sender->getInventory()->removeItem($item);
                    $newItem = $item->setDamage(0);
                    $sender->getInventory()->setItemInHand($newItem);
                    $sender->sendMessage('§7► §eПредмет как новенький!');
                } else {
                    $sender->sendMessage('§7► §сЭту вещь починить не получится');
                }

                break;

            case "getping":
                if (isset($args[0])) {
                    $player2 = $this->getServer()->getPlayer($args[0]);
                    if (!($player2)) return $sender->sendMessage("§7► §cИгрок не найден или не в сети!");
                    $ping = $player2->getPing();
                    $sender->sendMessage("§7► §eУ игрока §a{$player2->getName()} §eпинг §6{$ping}");
                    return true;
                } else {
                    $player = $sender->getPlayer();
                    $ping = $player->getPing();
                    $sender->sendMessage("§7► §eТвой пинг §6{$ping}");
                    return true;
                }
                break;

            case "rot":
                if (!$sender->isOp()) {
                    $sender->sendMessage("§7► §cЭта команда только для §6OP");
                    break;
                }

                $rotation = $sender->getLocation();
                $yaw = round($rotation->yaw, 1);
                $pitch = round($rotation->pitch, 1);
                $x = round($rotation->x, 1);
                $y = round($rotation->y, 1);
                $z = round($rotation->z, 1);
                $sender->sendMessage(
                    "§l§eY§7: §6" . $yaw . ", §l§eP§7: §6" . $pitch . ", §l§eX§7: §6" . $x . ", §l§eY§7: §6" . $y . ", §l§eZ§7: §6" . $z
                );
                unset($rotation, $yaw, $pitch);
                break;

            case "spawn":
                $chunkX = $x >> 4;
                $chunkZ = $z >> 4;

                for ($dx = -1; $dx <= 1; $dx++) {
                    for ($dz = -1; $dz <= 1; $dz++) {
                        $level->loadChunk($chunkX + $dx, $chunkZ + $dz, true);
                    }
                }

                $sender->teleport(new Position($x, $y, $z, $this->getServer()->getDefaultLevel()));
                $sender->sendTitle("", " §7<< §l§6СПАВН §f>>\n §l§eСкидки §c40%", 10, 10, 30);

                break;

            case "size":
                if ($sender->hasPermission("fapi.cmd.size")) {
                    if (!isset($args[0])) return $sender->sendMessage('§7► §eИспользовать§7: §7/§6size small/normal/big');
                    if ($args[0] === 'small') {
                        Main::$size[$sender->getName()] = true;
                        $sender->setDataProperty(Player::DATA_SCALE, Player::DATA_TYPE_FLOAT, 0.7);
                        $sender->sendMessage("§7► §eТвой размер теперь сравним с размером §6маленькой мышки");
                    }

                    if ($args[0] === 'normal') {
                        unset(Main::$size[$sender->getName()]);
                        $sender->setDataProperty(Player::DATA_SCALE, Player::DATA_TYPE_FLOAT, 1.0);
                        $sender->sendMessage("§7► §eТвой рост стал §6нормальным");
                    }

                    if ($args[0] === 'big') {
                        Main::$size[$sender->getName()] = true;
                        $sender->setDataProperty(Player::DATA_SCALE, Player::DATA_TYPE_FLOAT, 2);
                        $sender->sendMessage("§7► §eТвой рост стал §6огромным");
                    }

                } else {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                }

                break;

            case "sayme":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.say")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }
                if (!isset($args[0])) {
                    return $sender->sendMessage("§7► §eИспользовать§7: §7/§6sayme (сообщение).");
                }

                $this->getServer()->broadcastMessage("§8[§a§l" . $sender->getName() . "§r§8] §e" . implode(" ", $args));
                break;

            case "gm":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.gm")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                if (isset($args[0]) and $args[0] == 3 and $sender->isOp()) {
                    $sender->setGamemode($args[0]);
                    $sender->sendMessage("§7► §cУ тебя режим §6Зрителя");
                    break;
                }

                if (isset(Main::$spec[$sender->getLowerCaseName()])) {
                    $sender->sendMessage("§7► §cТы в режиме §6Слежки");
                    return;
                }

                $playerName = $sender->getPlayer()->getName();
                if ($sender->getGamemode() == Player::SURVIVAL) {
                    $this->drops[$playerName]['content'] = $sender->getInventory()->getContents();
                    $this->drops[$playerName]['hand'] = $sender->getOffhandInventory()->getItemInOffHand() !== null ? $sender->getOffhandInventory()->getItemInOffHand() : Item::get(0, 0, 0);
                    $sender->setGamemode(1);
                    $sender->sendMessage("§7► §eТы §aуспешно§e сменил свой игровой режим на §6Креатив");
                } elseif ($sender->getGamemode() == Player::CREATIVE) {
                    $sender->setGamemode(0);
                    $sender->sendMessage("§7► §eТы §aуспешно§e сменил свой игровой режим на §6Выживание");
                    if (isset($this->drops[$playerName])) {
                        foreach ($this->drops[$playerName]['content'] as $slots => $lol) {
                            if ($lol instanceof Item) {
                                $sender->getInventory()->setItem($slots, $lol);
                            } else {
                                $item = Item::get(
                                    (int)$lol['id'],
                                    (int)($lol['damage'] ?? 0),
                                    (int)($lol['count'] ?? 1),
                                    (string)($lol['nbt'] ?? (isset($lol['nbt_hex']) ? hex2bin($lol['nbt_hex']) : ''))
                                );
                                $sender->getInventory()->setItem($slots, $item);
                            }
                        }

                        if ($this->drops[$playerName]['hand'] instanceof Item) {
                            $sender->getOffhandInventory()->setItemInOffHand($this->drops[$playerName]['hand']);
                        } else {
                            $lol = $this->drops[$playerName]['hand'];
                            $sender->getOffhandInventory()->setItemInOffHand(
                                Item::get(
                                    (int)$lol['id'],
                                    (int)($lol['damage'] ?? 0),
                                    (int)($lol['count'] ?? 1),
                                    (string)($lol['nbt'] ?? (isset($lol['nbt_hex']) ? hex2bin($lol['nbt_hex']) : ''))
                                )
                            );
                        }
                        unset($this->drops[$playerName]);
                    }
                } else {
                    $sender->setGamemode(0);
                    $sender->sendMessage("§7► §eТы §aуспешно§e сменил свой игровой режим на §6Выживание");
                }

                break;

            case "clearchat":
                if (!$sender->hasPermission("fapi.cmd.cc")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                foreach ($this->getServer()->getOnlinePlayers() as $p) {
                    $p->sendMessage(
                        "\n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n "
                    );
                    $p->sendMessage("§8[§6Чат§8] §a" . $sender->getName() . "§e очистил(а) чат!");
                }

                break;

            case "god":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.god")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                if (!isset(Main::$god[$sender->getName()]) || !Main::$god[$sender->getName()]) {
                    $sender->sendMessage("§7► §eРежим §6бога §aвключен§e!");
                    Main::$god[$sender->getName()] = true;
                } else {
                    $sender->sendMessage("§7► §eРежим §6бога §cвыключен§e!");
                    unset(Main::$god[$sender->getName()]);
                }

                break;

            case "l":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.suicide")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                $sender->setHealth(0);
                break;

            case "leave":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.leave")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                $sender->teleport(new Vector3($sender->getX(), -2, $sender->getZ()));
                $sender->sendMessage("§7Телепортация..");
                break;

            case "top":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.top")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                $sender->teleport(new Vector3($sender->getX(), 128, $sender->getZ()));
                $sender->sendMessage("§7Телепортация..");
                break;

            case "clear":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.clear")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                $sender->getInventory()->clearAll();
                $sender->sendTitle("§eТы §6очистил", " §eсвой инвентарь.");
                break;

            case "fly":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.fly")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                if ($sender->getAllowFlight()) {
                    $sender->setAllowFlight(false);
                    $sender->setFlying(false);
                    $sender->sendMessage("§7► §eТы успешно §cотключил §eрежим полёта!");
                } else {
                    $sender->setAllowFlight(true);
                    $sender->sendMessage("§7► §eТы успешно §aвключил §eрежим полёта!");
                }

                break;

            case "back":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.back")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                if (isset($this->death[$sender->getName()])) {
                    $sender->teleport($this->death[$sender->getName()]);
                    $sender->sendMessage("§7► §eТы успешно телепортировался на место гибели!");
                } else {
                    $sender->sendMessage("§7► §cТы не умирал!");
                }

                break;

            case "heal":
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.heal")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                if ($sender->getGamemode() == 0) {
                    $sender->setMaxHealth(20);
                    $sender->setHealth(20);
                    $sender->setFood(20);
                    $sender->sendTitle("§eТы успешно", "§eвосстановил свои §cжизни§e!");
                } else {
                    $sender->sendMessage(
                        "§7► §cТы не можешь использовать данную команду в режиме §6Креатив§c!"
                    );
                }

                break;

            case "v":
                if ($sender->getGamemode() != 1) return $sender->sendMessage("§7► §сИспользуйте в §6Креатив");
                if (!$sender->getPlayer()->hasPermission("fapi.cmd.vanish")) {
                    $sender->sendMessage("§7► §cУ тебя нет прав на использование данной команды");
                    break;
                }

                if (isset($args[0])) {
                    if ($args[0] == "on") {
                        Main::$vanish[$sender->getName()] = true;
                        $effect = Effect::getEffect(14)->setVisible(false)->setAmplifier(10)->setDuration(1928000);
                        $sender->addEffect($effect);
                        $sender->sendTitle("§eТы", "§aвключил §bневидимость!");
                    }

                    if ($args[0] == "off") {
                        Main::$vanish[$sender->getName()] = false;
                        $sender->removeAllEffects();
                        $sender->sendTitle("§eТы", "§cвыключил §bневидимость!");
                    }

                } else {
                    $sender->sendMessage("§7► §eИспользуйте§7: §7/§6v on§7/§6off!");
                }

                break;

            case "day":
                $sender->getLevel()->setTime(0);
                $sender->sendMessage("§7► §eТы поставил §6День");
                $nick = $sender->getName();
                $this->getServer()->broadcastMessage("§7► §a$nick §eпоставил §6День");
                break;

            case "night":
                $sender->getLevel()->setTime(14000);
                $sender->sendMessage("§7► §eТы поставил §6Ночь");
                $nick = $sender->getName();
                $this->getServer()->broadcastMessage("§7► §a$nick §eпоставил §6Ночь");
                break;

            case "totem":
                if (!isset($this->totem[$sender->getName()])) {
                    $this->totem[$sender->getName()] = 1;
                    $totem = Item::get(450, 0, 1);
                    $sender->getInventory()->addItem($totem);
                    $sender->sendMessage("§7► §eТы успешно получил §6Тотем");
                } else {
                    $sender->sendMessage("§7► §cДанная команда тебе будет доступна после рестарта");
                }

                break;

            case "mypos":
                $x = $sender->getFloorX();
                $y = $sender->getFloorY();
                $z = $sender->getFloorZ();
                $sender->sendMessage("§7► §eТвои координаты§7: §6{$x}§7, §6{$y}§7, §6{$z}");
                break;
        }
    }

    public static function playerGetGamemode(Player $player) {
        if($player->getGamemode() == 0) return "Выживание";
        
        if($player->getGamemode() == 1) return "Креатив";
        
        if($player->getGamemode() == 2) return "Приключение";
        
        if($player->getGamemode() == 3) return "Наблюдатель";
    }

    public function randomArmorColors(){
        foreach($this->armors as $name => $p){
            $r = mt_rand(1, 255);
            $g = mt_rand(1, 255);
            $b = mt_rand(1, 255);
            $inventory = $p->getInventory();
            $color = Color::getRGB($r,$g,$b);
            $helmet = Item::get(298);
            $chestplate = Item::get(299);
            $leggings = Item::get(300);
            $boots = Item::get(301);
            $helmet->setCustomColor($color);
            $chestplate->setCustomColor($color);
            $leggings->setCustomColor($color);
            $boots->setCustomColor($color);
            $inventory->setHelmet($helmet);
            $inventory->setChestplate($chestplate);
            $inventory->setLeggings($leggings);
            $inventory->setBoots($boots);
        }
    }

    public function updateTask() {
        $effect = Effect::getEffect(16);
        $effect->setDuration(20 * 20);
        $effect->setVisible(false);

        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if (Helper::getWorldName($player->getLevel()->getFolderName()) !== null) {
                $repeating = str_repeat(" ", 87);
                $endRepeating = str_repeat("\n ", 11);

                $date = time();

                $month_en_to_ru = [
                    'Jan' => 'янв',
                    'Feb' => 'фев',
                    'Mar' => 'мар',
                    'Apr' => 'апр',
                    'May' => 'май',
                    'Jun' => 'июн',
                    'Jul' => 'июл',
                    'Aug' => 'авг',
                    'Sep' => 'сен',
                    'Oct' => 'окт',
                    'Nov' => 'ноя',
                    'Dec' => 'дек',
                ];

                $date_en = strftime("%d %b. %Y", $date);
                $date_ru = str_replace(array_keys($month_en_to_ru), array_values($month_en_to_ru), $date_en);

                $playerName = strtolower($player->getName());

                if($level = $this->lvlSystem->cfg->get($playerName) == null) {
                    $level = 0;
                } else {
                    $level = $this->lvlSystem->cfg->get($playerName);
                }

                if($this->killss->get($playerName) == null) {
                    $kills = 0;
                } else {
                    $kills = $this->killss->get($playerName);
                }

                if (isset($this->clanSystem->players[$playerName])) {
                    $clanName = $this->clanSystem->players[$playerName];
                } else {
                    $clanName = "§7Не в клане";
                }

                $rank = $this->ranks->getRanksManager()->getRankByPlayerName($playerName);

                $block1 = 
                    $repeating . " §fДенег§7: §e" . number_format(EconomyAPI::myMoney($player)) . "§6$\n" .
                    $repeating . " §fАметисты§7: §e" . number_format(AmethystsManager::myAmethysts($player)) . " §d§r\n\n";

                $block2 = 
                    $repeating . " §fРанг§7: §e" . $rank . " §7(§f" . number_format($kills) . " §7)\n" .
                    $repeating . " §fКлан§7: §6" . $clanName . "\n\n";

                $block = mt_rand(1, 2) == 1 ? $block1 : $block2;

                $player->sendTip(
                    $repeating . "§eＣｏｓｍｉｘ§6ＰＥ §cＧｒｉｅｆ§r §7(". $player->getPing() . "ms)\n" . 
                    $repeating . "       §7" . $date_ru . "\n\n" .
                    $repeating . " §fОнлайн§7: §e" . count($this->getServer()->getOnlinePlayers()) . "§8/§6" . $this->getServer()->getMaxPlayers() . "§r\n" .
                    $repeating . " §fМир§7: " . Helper::getWorldName($player->getLevel()->getFolderName()) . "\n\n" .
                    $block .
                    $repeating . " §fУровень§7: §8(§a" .  $level . "§8)\n" .
                    $repeating . " §fНаиграно§7: " . Helper::convertTimeOptimized($this->getTime($player)) . "\n\n" .
                    $repeating . "§7* §bvk.com/cosmixpe\n" . 
                    $repeating . "§7* §ecosmixpe.ru" . 
                    $endRepeating
                );
            }

            # $player->addEffect($effect);

            $data = self::$gameTime->getAll();
            if (isset($data[($playerName = strtolower($player->getName()))])) {
                $data[$playerName] = $data[$playerName] + 1;
            } else {
                $data[$playerName] = 0;
            }

            self::$gameTime->setAll($data);
            self::$gameTime->save();
        }

        foreach ($this->getServer()->getLevels() as $level) {
            foreach ($level->getEntities() as $entity) {
                if (strpos($entity->getNameTag(), "§6АРЕНА") !== false) {
                    $entity->setNameTag(
                        "    §l§7▼ §6АРЕНА §8(§r§eонлайн§7: §a" . count($this->getServer()->getLevelByName('pvparena')->getPlayers()) . "§8) §7▼§r" .
                        "\n§fНажми, чтобы телепортироваться!"
                    );
                    $entity->setScale(1.5);
                } elseif (strpos($entity->getNameTag(), "§aМИР ВЫЖИВАНИЯ") !== false) {
                    $entity->setNameTag(
                        "§l§7▼ §aМИР ВЫЖИВАНИЯ §8(§r§eонлайн§7: §a" . count($this->getServer()->getLevelByName('world')->getPlayers()) . "§8) §7▼§r" .
                        "\n§fНажми, чтобы телепортироваться!"
                    );
                    $entity->setScale(1.5);
                } elseif ($entity->getNameTag() == '§7soon..') {
                     $entity->setScale(1.2);
                }
            }
        }
    }

    public function setMaxHp() {
        foreach ($this->maxhp as $playerName) {
            $player = $this->getServer()->getPlayer($playerName);

            if ($player instanceof Player) {
                $player->setMaxHealth(25);
            }
        }
    }

    public function stopTimer($player) {
        $time = $this->getTime($player);
        $name = strtolower($player->getName());
        $this->timer[$name] = $time;
        unset($this->timers[$player->getId()]);
    }

    public function getTime($player) {
        $ct = 0;
        $name = strtolower($player->getName());

        if (isset($this->timer[$name])) $ct = $this->timer[$name];

        $st = 0;
        if (isset($this->timers[$player->getId()])) {
            $st = $this->timers[$player->getId()];
            $st = time() - $st;
        }

        return $ct + $st;
    }

    public function getTimerBase() {
        return $this->timer;
    }

    public function getTargetName(string $senderName) {
        return key($this->sitPlayers[$senderName]);
    }

    public function checkExpiredSits() {
        $currentTime = time();
        foreach ($this->pendingSits as $senderName => &$requests) {
            foreach ($requests as $targetName => $expireTime) {
                if ($expireTime < $currentTime) {
                    unset($requests[$targetName]);
                }
            }
            if (empty($requests)) {
                unset($this->pendingSits[$senderName]);
            }
        }
    }

    public function toggleSit(Player $sender, Player $targetPlayer) {
        $senderName = $sender->getName();
        $targetName = $targetPlayer->getName();

        if ($this->isSitting($senderName, $targetName)) {
            $this->standUp($sender, $targetPlayer);
        } else {
            $this->sitDown($sender, $targetPlayer);
        }
    }

    public function isSitting(string $senderName, string $targetName) {
        return isset($this->sitPlayers[$senderName][$targetName]);
    }

    public function sitDown(Player $sender, Player $targetPlayer) {
        $senderName = $sender->getName();
        $targetName = $targetPlayer->getName();

        $sitEntity = new SittingEntity($targetPlayer->level, $this->createNBT($targetPlayer));
        $sitEntity->spawnToAll();

        $this->getServer()->getScheduler()->scheduleRepeatingTask(new SittingTask($this, $targetPlayer, $sitEntity, $sender), 1);

        $this->sitPlayers[$senderName][$targetName] = $sitEntity->getId();

        foreach ($sender->getLevel()->getPlayers() as $player) {
            $pk = new SetEntityLinkPacket();
            $pk->from = $sitEntity->getId();
            $pk->to = $sender->getId();
            $pk->type = SetEntityLinkPacket::TYPE_PASSENGER;
            $player->dataPacket($pk);
        }

        $sender->sendMessage("§7► §eТы сел(а) на игрока §a$targetName");
        $targetPlayer->sendMessage("§7► §eНа тебя сел(а) игрок §a$senderName");
    }

    public function teleportSitEntityToTargetPlayer($target, $entity) {
        $entity->teleport(new Vector3($target->getX(), $target->getY() + 3, $target->getZ()));
    }

    public function standUp(Player $sender, string $targetName) {
        $senderName = $sender->getName();

        if (isset($this->sitPlayers[$senderName][$targetName])) {
            $sitEntityId = $this->sitPlayers[$senderName][$targetName];

            foreach ($sender->getLevel()->getPlayers() as $player) {
                $pk = new SetEntityLinkPacket();
                $pk->from = $sitEntityId;
                $pk->to = $sender->getId();
                $pk->type = SetEntityLinkPacket::TYPE_REMOVE;
                $player->dataPacket($pk);
            }

            unset($this->sitPlayers[$senderName][$targetName]);
            unset($this->sitPlayers[$senderName]);

            $sender->sendMessage("§7► §eТы встал(а) с игрока §a$targetName");
            if ($targetPlayer = $this->getServer()->getPlayer($targetName)) $targetPlayer->sendMessage("§7► §eС тебя встал(а) §a$senderName");

            $this->despawnSittingEntity($sitEntityId);
        }
    }

    public function despawnSittingEntity(int $entityId) {
        $entity = $this->getServer()->findEntity($entityId);
        $entity->close();
    }

    public function createNBT(Player $player) {
        return new CompoundTag(
            "",
            [
                new ListTag(
                    "Pos",
                    [
                        new DoubleTag("", $player->x),
                        new DoubleTag("", $player->y + 3),
                        new DoubleTag("", $player->z)
                    ]
                ),
                new ListTag(
                    "Motion",
                    [
                        new DoubleTag("", $player->motionX),
                        new DoubleTag("", $player->motionY),
                        new DoubleTag("", $player->motionZ)
                    ]
                ),
                new ListTag(
                    "Rotation",
                    [
                        new FloatTag("", $player->yaw),
                        new FloatTag("", $player->pitch)
                    ]
                )
            ]
        );
    }

    private function isInventoryEmpty(Player $player) {
        foreach ($player->getInventory()->getContents() as $item) {
            if ($item->getId() !== 0) {
                return false;
            }
        }

        return true;
    }

    public function broadcaster() {
        switch (mt_rand(1, 12)) {
            case 1:
                $msg = "§d┇ §eУ нас в группе ВКонтакте §6частые конкурсы§e!\n§d┇\n§d┇ §eНаша группа ВКонтакте - §6vk.com/cosmixpe\n ";
                break;

            case 2:
                $msg = "§d┇ §eНа сервере есть §6арена§e!\n§d┇\n§d┇ §eДля телепортации - §6/arena\n ";
                break;

            case 3:
                $msg = "§d┇ §eНа сервере есть §6кланы§e!\n§d┇\n§d┇ §eИнформация о кланах - §6/c help\n ";
                break;

            case 4:
                $msg = "§d┇ §eНа сайте проходят §6скидки §e- §650%§e!\n§d┇\n§d┇ §eСайт - §6cosmixpe.ru\n ";
                break;

            case 5:
                $msg = "§d┇ §eУ нас есть телеграм канал!\n§d┇\n§d┇ §eНаш телеграм канал - §6t.me/cosmixpe\n ";
                break;

            case 6:
                $msg = "§d┇ §eУ нас есть ютуб канал!\n§d┇\n§d┇ §eНаш ютуб канал - §6youtube.com/@cosmixpe\n ";
                break;

            case 7:
                $msg = "§d┇ §eУ нас есть дискорд сервер!\n§d┇\n§d┇ §eНаш дискорд сервер - §6discord.com/invite/g26cbycSXe\n ";
                break;

            case 8:
                $msg = "§d┇ §eНа сервере есть §6ранги§e!\n§d┇\n§d┇ §eИнформация о рангах - §6/rangs\n ";
                break;

            case 9:
                $msg = "§d┇ §eХочешь посмотреть свою статистику?\n§d┇\n§d┇ §eИспользуй - §6/stats\n ";
                break;

            case 10:
                $msg = "§d┇ §eХочешь поменять пароль?\n§d┇\n§d┇ §eИспользуй - §6/parol\n ";
                break;

            case 11:
                $msg = "§d┇ §eНа сервере есть §6души§e!\n§d┇\n§d┇ §eИнформация о душах - §6/souls\n ";
                break;

            case 12:
                $msg = "§d┇ §eЧтобы писать в глобальный чат\n§d┇\n§d┇ §eПиши - §6!сообщение\n ";
                break;
        }

        foreach ($this->getServer()->getOnlinePlayers() as $p) {
            $p->sendMessage("\n$msg");
        }
    }

    public function getCommandsInfo(CommandSender $sender, $command) : bool { 
        $info = $this->infoAboutCommands->get($command);
        if ($info !== false) {
            foreach ($info as $row) {
                $sender->sendMessage($row);
            }
            unset($info);
            return true;
        } else {
            return false;
        }
    }

    public function clearEntities(bool $access = false) {
        if ($access) {
            $count = array(0, 0);
            foreach ($this->getServer()->getLevels() as $level) {
                foreach ($level->getEntities() as $entity) {
                    if ($entity instanceof Player or $entity instanceof SlapperHuman or $entity instanceof SlapperVillager or $entity instanceof Wither2 or $entity instanceof Evoker or $entity instanceof FallingSand or $entity instanceof Vindicator or $entity instanceof Villager or $entity instanceof Zombie or $entity instanceof Human or $entity instanceof Wither or $entity instanceof WitherSkull2 or $entity instanceof WitherGuardian or $entity instanceof Silverfish2 or $entity instanceof BigSkeleton or $entity instanceof WitherSkeleton2 or $entity instanceof BigSpider) continue;
                    if ($entity instanceof Creature) continue;
                    if (!isset($this->entities[$entity->getID()])) {
                        if (!($entity instanceof Creature)) {
                            $count[0]++;
                            $entity->close();
                        }
                    }
                }
            }
            $this->getServer()->broadcastPopup(" §eОчищено §6{$count[0]} §eмусора");
        } else {
            $this->getServer()->broadcastPopup("§7► §eОчистка мусора через §a20 §eсекунд");
            $this->getServer()->getScheduler()->scheduleDelayedTask(new CallbackTask(array($this, "clearEntities"), array(true)), 20 * 20);
        }
    }

    public function removeCreativeItem() {
        $remItem = $this->infoAboutCommands->get("removeCreativeItem");
        foreach ($remItem as $rowItem) {
            $rowItem = explode(", ", $rowItem);
            item::removeCreativeItem(Item::get($rowItem[0], $rowItem[1]));
        }
    }

    public function deathManager($d, $p) {
        if (isset(Main::$vendetta[strtolower($d->getName())]) and Main::$vendetta[strtolower($d->getName())] == strtolower($p->getName())) {
            $money = rand(200, 500) * 2;
            $d->sendMessage("§7► §eТы отомстил игроку §a" . $p->getName() . "§e! Награда §bx2§7: §a+ §e" . $money . "§6$\n\n");
        } else {
            $money = rand(200, 500);
            $d->sendMessage("§7► §eТы убил игрока §a" . $p->getName() . "§e! Награда §a+ §e" . $money . "§6$\n\n");
        }

        EconomyAPI::addMoney($d, $money);

        $p->sendMessage("§7► §eТебя убил игрок §a" . $d->getName());
        $p->sendMessage("§7► §eУ него оставалось §f" . $d->getHealth() . "§c❤\n\n");

        Main::$vendetta[strtolower($p->getName())] = strtolower($d->getName());
    }

    public static function checkKill(Player $killer, $victimIP) : bool
    {
        $killerName = strtolower($killer->getName());
        if (!isset(Main::$killsLimit[$killerName][$victimIP])) {
            Main::$killsLimit[$killerName][$victimIP] = 0;
        }
        return ++Main::$killsLimit[$killerName][$victimIP] <= 3;
    }

    public function saveConfig() {
        $kills = new Config($this->getDataFolder() . "resourses/kills.json", Config::JSON);
        $drops = new Config($this->getDataFolder() . 'resourses/drops.json', Config::JSON);
        $timer = new Config($this->getDataFolder() . 'resourses/timer.json', Config::JSON);
        $free = new Config($this->getDataFolder()."resourses/free_data.json", Config::JSON);
        $sozd = new Config($this->getDataFolder()."resourses/sozd.json", Config::JSON);
        $free->setAll($this->freeData);
        $sozd->setAll($this->sozd);
        $drops->setAll($this->drops);
        $kills->setAll($this->kills);
        $timer->setAll($this->timer);
        $free->save();
        $sozd->save();
        $timer->save();
        $drops->save();
        $kills->save();
    }

    public function getKillerList() {
        $this->saveConfig();
        $this->kills = (new Config($this->getDataFolder() . "resourses/kills.json", Config::JSON))->getAll();
        if (empty($this->kills)) {
            return null;
        } else {
            return $this->kills;
        }
    }

    public function sendTopKills(Player $player) {
        $vector = new Vector3(-20, 59, -38);
        arsort($this->kills);
        $c = 0;
        $text = "   §6⚔ §fЛучшие убийцы 2-х недель §l§eＣｏｓｍｉｘ§6ＰＥ§r §6⚔\n";
        foreach ($this->kills as $p => $kills) {
            if (++$c === 6) break;
            $end = $c !== 6 ? "\n" : null;
            if ($c == 1) {
                $end = " §7(§e+ §62 §eДонат-Кейса§7)§r\n";
            }

            if ($c == 2) {
                $end = " §7(§e+ §61 §eДонат-Кейс§7)§r\n";
            }

            if ($c == 3) {
                $end = " §7(§a+ §e20.000§6\$§7)§r\n";
            }

            $text .= "§f#" . $c . ". §a" . $p . "  §eсделал §a" . $kills . " §6убийств" . $end;
        }

        $this->getServer()->getLevelByName('pvparena')->addParticle(new FloatingTextParticle($vector, "", $text), [$player]);
    }

    public function getKillInfo($info, $k, $kk) {
        if (empty($info->getAll())) {
            $info->set("u", (int)time() + 60 * 60 * 24 * 14);
            $info->set("winners", []);
            $info->set("winners2", []);
            $info->save();
        } else {
            $lastTime = $info->get("u", 0);
            if ($lastTime <= (int)time()) {
                echo "1st\n";
                arsort($k);
                $w = [];
                $c = 0;

                foreach ($k as $player => $kills) {
                    if (++$c === 4) {
                        break;
                    }
                    $w[$player] = $c;
                }

                $info->set("u", (int)time() + 60 * 60 * 24 * 14);
                $info->set("winners", $w);
                $info->set("winners2", $w);
                $info->save();
                $this->winners = $w;
                $this->kills = [];
                $c = $kk;
                $c->setAll([]);
                $c->save();
            }
        }

        if (!empty($info->get("winners", []))) {
            $this->winners = $info->get("winners", []);
        }

        if (!empty($info->get("winners2", []))) {
            $this->winners2 = $info->get("winners2", []);
        }

        if ($info->get("u", 0) === 0) {
            $info->set("u", (int)time() + 60 * 60 * 24 * 14);
            $info->save();
        }

        unset($k);
        $this->saveConfig();
    }

    public static function sendSound(Player $player, string $soundName, float $pitch = 1.0, float $volume = 1.0) {
        $pk = new class extends PlaySoundPacket {
            public function decode() {
                $this->sound = $this->getString();
                $this->getBlockCoords($this->x, $this->y, $this->z);
                $this->x /= 8;
                $this->y /= 8;
                $this->z /= 8;
                $this->volume = $this->getLFloat();
                $this->float = $this->getLFloat();
            }

            public function encode() {
                $this->reset();
                $this->putString($this->sound);
                $this->putBlockCoords((int)($this->x * 8), (int)($this->y * 8), (int)($this->z * 8));
                $this->putLFloat($this->volume);
                $this->putLFloat($this->float);
            }
        };

        $pk->sound = $soundName;
        $pk->x = $player->getFloorX();
        $pk->y = $player->getFloorY();
        $pk->z = $player->getFloorZ();
        $pk->volume = $volume;
        $pk->float = $pitch;

        $player->dataPacket($pk);
    }

    public function sendSoundToPlayers(string $soundName) {
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            if (!in_array($player->getName(), $this->music)) {
                continue;
            }

            $stopSoundPacket = new StopSoundPacket();
            $stopSoundPacket->soundName = '';
            $stopSoundPacket->stopAll = true;
            $player->dataPacket($stopSoundPacket);

            $this->sendSound($player, $soundName);
        }
    }

    public function onDisable() {
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $this->stopTimer($p);
        }

        $this->saveConfig();
    }
}